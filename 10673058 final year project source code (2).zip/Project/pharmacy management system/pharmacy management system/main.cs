﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace pharmacy_management_system
{
    public partial class main : Form
    {
        public main()
        {
           
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            login fm = new login();
            fm.Show();
            Hide();
        }

        private void btnviewuser_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            invoice1.Hide();
            medicine_21.Hide();
            suppiler11.Hide();
            purchase1.Hide();
            stock2.Hide();
            
            dashboard11.Show();
            dashboard11.BringToFront();

        }

        private void btninvoice_Click(object sender, EventArgs e)
        {
            //hide other usercontrols
            medicine_21.Hide();
            suppiler11.Hide();
            purchase1.Hide();
            stock2.Hide();
            dashboard11.Hide();
           

            // show current user controls
            invoice1.Show();
            invoice1.BringToFront();
        }

        private void treeView1_AfterSelect_1(object sender, TreeViewEventArgs e)
        {

        }

        private void treeView2_AfterSelect(object sender, TreeViewEventArgs e)
        {
          
        }

        private void btnaddmedicine_Click(object sender, EventArgs e)
        {
         
            

        }

        private void btnuser_Click(object sender, EventArgs e)
        {
            
        }

        private void main_Load(object sender, EventArgs e)
        {
           invoice1.Hide();
            purchase1.Hide();
           stock2.Hide();
            suppiler11.Hide();
            medicine_21.Hide();
            
            dashboard11.Show();
            dashboard11.BringToFront();

        }

        private void lblAdmin_Click(object sender, EventArgs e)
        {

        }

        private void btnmedicine_Click(object sender, EventArgs e)
        {
            //hide other usercontrols
             invoice1.Hide();
           purchase1.Hide();
          stock2.Hide();
            suppiler11.Hide();
           

            //show current user controls
            medicine_21.Show();
            medicine_21.BringToFront();
          



        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void invoice1_Load(object sender, EventArgs e)
        {
            //medicine_21.Hide();
            // invoice1.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {//hide other usercontrols
         invoice1.Hide();
         purchase1.Hide();
         stock2.Hide();
         medicine_21.Hide();

            //show current user controls
            suppiler11.Show();
            suppiler11.BringToFront();

        }

        private void suppiler21_Load(object sender, EventArgs e)
        {

        }

        private void btnpurchase_Click(object sender, EventArgs e)
        {
            //hide other usercontrols
            invoice1.Hide();
            suppiler11.Hide();
            stock2.Hide();
            medicine_21.Hide();
            
            

            //show current user controls
            purchase1.Show();
            purchase1.BringToFront();

        }

        private void btnstock_Click(object sender, EventArgs e)
        {

            stock2.Show();
            //hide other usercontrols
             invoice1.Hide();
             suppiler11.Hide();
            purchase1.Hide();
            medicine_21.Hide();
            dashboard11.Hide();

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void medicine_21_Load(object sender, EventArgs e)
        {

        }

        private void suppiler11_Load(object sender, EventArgs e)
        {

        }

        private void stock1_Load(object sender, EventArgs e)
        {

        }

        private void invoice1_Load_1(object sender, EventArgs e)
        {

        }

        private void purchase1_Load(object sender, EventArgs e)
        {

        }
    }
}
