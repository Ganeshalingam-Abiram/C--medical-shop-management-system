﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class Manageinvoice : UserControl
    {
        public Manageinvoice()
        {
            InitializeComponent();
        }

        private void btnview_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Invoice_Medicine", con);
            DataTable dtb1 = new DataTable();
            sqlDa.Fill(dtb1);
            dataGridViewManageinvoice.DataSource = dtb1;
            con.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");


            if (MessageBox.Show("Are you Sure? ", "Delete Confirmation !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {

                SqlCommand cmd = new SqlCommand();
                if (dataGridViewManageinvoice.RowCount > 1 && dataGridViewManageinvoice.SelectedRows[0].Index != dataGridViewManageinvoice.RowCount - 1)
                {
                    cmd.CommandText = "DELETE FROM Invoice_Medicine WHERE Invoice_NO =" + dataGridViewManageinvoice.SelectedRows[0].Cells[0].Value + "";
                    con.Open();
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    con.Close();
                    dataGridViewManageinvoice.Rows.RemoveAt(dataGridViewManageinvoice.SelectedRows[0].Index);
                    MessageBox.Show("Row Deleted");

                }
            }
        }

        private void dataGridViewManageinvoice_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
