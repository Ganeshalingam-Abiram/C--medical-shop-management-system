﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class Suppiler1 : UserControl
    {
        public Suppiler1()
        {
            InitializeComponent();
        }

        private void Suppiler1_Load(object sender, EventArgs e)
        {

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtsuppilernumber.Clear();
            txtmedicineid.Clear();
            txtsuppileremail.Clear();
            txtsuppilernumber.Clear();
            txtsuppilername.Clear();
            txtsalesrepnumber.Clear();
            txtbalance.Clear();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnsave_Click_1(object sender, EventArgs e)
        {
            if (txtmedicineid.Text != "" && txtsuppilername.Text != "" && txtmedicineid.Text != "" && txtsuppileremail.Text != "" && txtsalesrepnumber.Text != "" && txtbalance.Text != "")

            {
                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();

                SqlCommand cmd = new SqlCommand("INSERT INTO Suppilerdetails (Suppiler_ID,Suppiler_Name,Medicine_ID,[Suppiler_Office _Number],Suppiler_Email,[Sales Rep_ Phone],Balance )VALUES('" + txtsuppilerID.Text + "' ,'" + txtsuppilername.Text + "' , '" + txtmedicineid.Text + "','" + txtsuppilernumber.Text + "' ,'" + txtsuppileremail.Text + "','" + txtsalesrepnumber.Text + "','" + txtbalance.Text + "' )");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Data is insert .", "Information", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            else
            {
                MessageBox.Show("Enter all Data .", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void lblsuppiler_Click(object sender, EventArgs e)
        {

        }

        private void btnmanagemedicine_Click(object sender, EventArgs e)
        {
            managesupplier11.Show();
            updateSupplier1.Hide();
            
        }

        private void btnaddmedicine_Click(object sender, EventArgs e)
        {
            managesupplier11.Hide();
            updateSupplier1.Hide();
            


        }

        private void btnupdatesuppiler_Click(object sender, EventArgs e)
        {
            updateSupplier1.Show();
            managesupplier11.Hide();

        }

        private void updateSupplier1_Load(object sender, EventArgs e)
        {

        }

        private void managesupplier11_Load(object sender, EventArgs e)
        {

        }
    }
}
