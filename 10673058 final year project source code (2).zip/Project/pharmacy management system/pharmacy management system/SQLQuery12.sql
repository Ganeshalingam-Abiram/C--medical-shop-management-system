USE [pharamacy]
GO

UPDATE [dbo].[Invoice_Medicine]
   SET [Invoice_NO] = <Invoice_NO, varchar(50),>
      ,[Medicine_ID] = <Medicine_ID, int,>
      ,[Medicine Name] = <Medicine Name, varchar(50),>
      ,[Price Per Unit] = <Price Per Unit, money,>
      ,[No of Units] = <No of Units, varchar(50),>
      ,[Total Price] = <Total Price, money,>
      ,[Date Of Invoice] = <Date Of Invoice, datetime,>
 WHERE <Search Conditions,,>
GO


