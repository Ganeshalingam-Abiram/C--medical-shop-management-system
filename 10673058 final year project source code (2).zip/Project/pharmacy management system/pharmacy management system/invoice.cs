﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class invoice : UserControl
    {
        public invoice()
        {
            InitializeComponent();
        }

        private void lblCount_Click(object sender, EventArgs e)
        {

        }

        private void lblmedicineid_Click(object sender, EventArgs e)
        {

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtInvoice_No.Text != "" && txtmedicineid.Text != "" && txtmedicinename.Text != "" && txtdate.Text != "" &&  txtNoofUnit.Text != "" && txtTotal.Text  !=  "")
            {
                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Invoice_Medicine(Invoice_NO,Medicine_ID, [Medicine Name],[Price Per Unit],[No of Units],[Total Price],[Date of invoice] )VALUES('" + txtInvoice_No.Text + "' ,'" + txtmedicineid.Text + "' , '" + txtmedicinename.Text + "'," + txtPricePerUnit.Text + ",'" + txtNoofUnit.Text + "'," + txtTotal.Text + "," + txtdate.Text + ")");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Data is insert .", "Information", MessageBoxButtons.OK, MessageBoxIcon.None);

            }
            else
            {
                MessageBox.Show("Enter all Data .", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }


        private void txtmedicinename_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void invoice_Load(object sender, EventArgs e)
        {

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtInvoice_No.Clear();
            txtmedicineid.Clear();
            txtmedicinename.Clear();
            txtdate.Clear();
            txtNoofUnit.Clear();
            txtPricePerUnit.Clear();
            txtTotal.Clear();

        }

        private void txtInvoice_No_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txttotalprice_TextChanged(object sender, EventArgs e)
        {
            

           
            
            
        }

        private void txtNoofUnit_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPricePerUnit_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtmedicineid_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbldetails_Click(object sender, EventArgs e)
        {

        }

        private void lblsuppiler_Click(object sender, EventArgs e)
        {

        }

        private void lblmedicinename_Click(object sender, EventArgs e)
        {

        }

        private void btnmanageinvoice_Click(object sender, EventArgs e)
        {
            manageinvoice1.Show();
            update_Invoice1.Hide();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Int32 value1 = Convert.ToInt32(txtPricePerUnit.Text) * Convert.ToInt32(txtNoofUnit.Text);


            // txtTotal.Text =Convert.ToString( value1);

            double value1 = double.Parse(txtPricePerUnit.Text) * double.Parse(txtNoofUnit.Text);


            txtTotal.Text = Convert.ToString(value1);

        }

        private void btnaddinvoice_Click(object sender, EventArgs e)
        {
            manageinvoice1.Hide();
            update_Invoice1.Hide();
        }

        private void btnupdateinvoice_Click(object sender, EventArgs e)
        {
            update_Invoice1.Show();
            manageinvoice1.Hide();
        }

        private void update_Invoice1_Load(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
