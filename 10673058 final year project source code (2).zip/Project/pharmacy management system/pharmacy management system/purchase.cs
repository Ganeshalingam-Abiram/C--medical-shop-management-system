﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace pharmacy_management_system
{
    public partial class purchase : UserControl
    {
        public purchase()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblmedicineid_Click(object sender, EventArgs e)
        {

        }

        private void btnaddpurchase_Click(object sender, EventArgs e)
        {
            manage_Purchase1.Hide();
            update_Purchase1.Hide();
        }

        private void btnmanagepurchase_Click(object sender, EventArgs e)
        {
            manage_Purchase1.Show();
            update_Purchase1.Hide();
        }

        private void btnupdatepurchase_Click(object sender, EventArgs e)
        {
            manage_Purchase1.Hide();
            update_Purchase1.Show();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {

            if (txtpurchaseid.Text != "" && txtsuppiler.Text != "" && txtinvoiceno.Text != "" && txtpaymentype.Text != "" && txtquantity.Text != "" && txtpriceperunit.Text != "" && txtmedicinename.Text !=  "" && txtpurchasedate.Text != ""&& txttotal.Text != "")

            {


                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Purchase(Purchase_ID, Suppiler,Invoice_NO,[Payment Type],Quantity,[Price Per Unit],[Medicine Name],[Purchase Date],[PurchaseTotal])VALUES('" + txtpurchaseid.Text + "' , '" + txtsuppiler.Text + "','" + txtinvoiceno.Text + "','" + txtpaymentype.Text + "','" + txtpriceperunit.Text + "','" + txtquantity.Text + "' ,'" + txtmedicinename.Text + "','" + txtpurchasedate.Text + "' ,'" + txttotal.Text + "' )");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Data is insert .", "Information", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            else
            {
                MessageBox.Show("Enter all Data .", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void purchase_Load(object sender, EventArgs e)
        {

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtpurchaseid.Clear();
            txtsuppiler.Clear();
            txtinvoiceno.Clear();
            txtpaymentype.Clear();
            txtquantity.Clear();
            txtpriceperunit.Clear();
            txtmedicinename.Clear();
            txtpurchasedate.Clear();
            txttotal.Clear();

        }

        private void manage_Purchase1_Load(object sender, EventArgs e)
        {

        }

        private void update_Purchase1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnaddinvoice_Click(object sender, EventArgs e)
        {
            double value1 = double.Parse(txtpriceperunit.Text) * double.Parse(txtquantity.Text);


            txttotal.Text = Convert.ToString(value1);
        }
    }
    }

