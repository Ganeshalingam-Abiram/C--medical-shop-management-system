﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsignin_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection con;

            connetionString = @"Data Source=MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@ ";
            con = new SqlConnection(connetionString);

            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Login where username = @username and password = @password", con);
            cmd.Parameters.AddWithValue("@username", txtusername.Text);
            cmd.Parameters.AddWithValue("@password", txtpassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count  > 0)
            {

                string value = Convert.ToString(dt.Rows[0].ItemArray[0]);
                if(value == "admin")
                {
                    Hide();
                    new Admin().Show();
                } else if (value == "phar")
                {
                    Hide();
                    new pharmacist().Show();
                }
                else if (value == "staff")
                {
                    Hide();
                   new main_staff().Show();
                }
                    Console.WriteLine(value);
                /* I have made a new page called home page. If the user is successfully authenticated then the form will be moved to the next form */
               
            }
            else
                MessageBox.Show("Invalid username or password");

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            
                txtusername.Clear();
                txtpassword.Clear();
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void lblAdmin_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
                    }
    }
    }

