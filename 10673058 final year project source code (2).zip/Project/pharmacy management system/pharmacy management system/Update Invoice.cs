﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class Update_Invoice : UserControl
    {
        public Update_Invoice()
        {
            InitializeComponent();
        }

        private void btnview_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Invoice_Medicine", con);
            DataTable dtb1 = new DataTable();
            sqlDa.Fill(dtb1);
            dataGridviewupdateinvoice.DataSource = dtb1;
            con.Close();
        }

        private void btnselect_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataReader rdr;
            DataSet ds;
            SqlDataAdapter da;

            if (dataGridviewupdateinvoice.RowCount > 1 && dataGridviewupdateinvoice.SelectedRows[0].Index != dataGridviewupdateinvoice.RowCount - 1)
            {
                cmd.CommandText = "select *  FROM Invoice_Medicine WHERE Invoice_NO =" + dataGridviewupdateinvoice.SelectedRows[0].Cells[0].Value + "";
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();
                bool temp = false;
                while (rdr.Read())
                {

                    String first = rdr.GetValue(0).ToString();
                    txtInvoice_No.Text = first;
                    txtmedicineid.Text = rdr.GetValue(1).ToString();
                    txtmedicinename.Text = rdr.GetValue(2).ToString();
                    txtdate.Text = rdr.GetValue(6).ToString();
                    txtPricePerUnit.Text = rdr.GetValue(3).ToString();
                    txtNoofUnit.Text = rdr.GetValue(4).ToString(); 
                    txttotalprice.Text = rdr.GetValue(5).ToString();
                     

                    temp = true;
                }
                if (temp == false)
                    MessageBox.Show("not found");
                con.Close();

            }
        }

        private void btnupdatesupplier_Click(object sender, EventArgs e)
        {
            if (txtInvoice_No.Text != "" && txtmedicineid.Text != "" && txtmedicineid.Text != "" && txtmedicinename.Text != "" && txtdate.Text != "" && txtPricePerUnit.Text != "" && txtNoofUnit.Text != "")
            {

                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();


                String query = "UPDATE Invoice_Medicine SET [Invoice_NO] = '" + txtInvoice_No.Text + "',Medicine_ID = '" + txtmedicineid.Text + "',   [Medicine Name]= '" + txtmedicinename.Text + "', [Price Per Unit] = '" + txtPricePerUnit.Text + "', [No of Units] = '" + txtNoofUnit.Text + "', [Total Price] = " + txttotalprice.Text + ", [Date Of Invoice] = '" + txtdate.Text + "'  where  Invoice_NO  = " + txtInvoice_No.Text;

                Console.WriteLine(query);
                SqlCommand cmd = new SqlCommand(query);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Record Updated Successfully .", "Information", MessageBoxButtons.OK, MessageBoxIcon.None);
            }



            else

            {
                MessageBox.Show("Enter all Data .", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtdate_TextChanged(object sender, EventArgs e)
        {

        }

        private void txttotalprice_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double value1 = double.Parse(txtPricePerUnit.Text) * double.Parse(txtNoofUnit.Text);


            txttotalprice.Text = Convert.ToString(value1);
        }
    }
    }

