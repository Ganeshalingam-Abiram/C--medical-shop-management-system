﻿namespace pharmacy_management_system
{
    partial class purchase
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnreset = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.txtsuppiler = new System.Windows.Forms.TextBox();
            this.txtpurchaseid = new System.Windows.Forms.TextBox();
            this.lblinvoiceno1 = new System.Windows.Forms.Label();
            this.lblmedicineid = new System.Windows.Forms.Label();
            this.btnaddpurchase = new System.Windows.Forms.Button();
            this.btnmanagepurchase = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtmedicinename = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.btnupdatepurchase = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.lblsuppiler = new System.Windows.Forms.Label();
            this.txtpurchasedate = new System.Windows.Forms.TextBox();
            this.btntotal = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.txtpaymentype = new System.Windows.Forms.TextBox();
            this.txtpriceperunit = new System.Windows.Forms.TextBox();
            this.update_Purchase1 = new pharmacy_management_system.Update_Purchase();
            this.manage_Purchase1 = new pharmacy_management_system.Manage_Purchase();
            this.SuspendLayout();
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnreset.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnreset.ForeColor = System.Drawing.Color.White;
            this.btnreset.Location = new System.Drawing.Point(576, 542);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(146, 36);
            this.btnreset.TabIndex = 56;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnsave.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnsave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnsave.Location = new System.Drawing.Point(381, 542);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(146, 36);
            this.btnsave.TabIndex = 55;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // txtsuppiler
            // 
            this.txtsuppiler.Location = new System.Drawing.Point(194, 245);
            this.txtsuppiler.Name = "txtsuppiler";
            this.txtsuppiler.Size = new System.Drawing.Size(331, 20);
            this.txtsuppiler.TabIndex = 50;
            // 
            // txtpurchaseid
            // 
            this.txtpurchaseid.Location = new System.Drawing.Point(196, 191);
            this.txtpurchaseid.Name = "txtpurchaseid";
            this.txtpurchaseid.Size = new System.Drawing.Size(331, 20);
            this.txtpurchaseid.TabIndex = 47;
            // 
            // lblinvoiceno1
            // 
            this.lblinvoiceno1.AutoSize = true;
            this.lblinvoiceno1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoiceno1.Location = new System.Drawing.Point(46, 300);
            this.lblinvoiceno1.Name = "lblinvoiceno1";
            this.lblinvoiceno1.Size = new System.Drawing.Size(123, 30);
            this.lblinvoiceno1.TabIndex = 41;
            this.lblinvoiceno1.Text = "Invoice_No";
            // 
            // lblmedicineid
            // 
            this.lblmedicineid.AutoSize = true;
            this.lblmedicineid.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicineid.Location = new System.Drawing.Point(74, 244);
            this.lblmedicineid.Name = "lblmedicineid";
            this.lblmedicineid.Size = new System.Drawing.Size(95, 30);
            this.lblmedicineid.TabIndex = 40;
            this.lblmedicineid.Text = "Suppiler";
            this.lblmedicineid.Click += new System.EventHandler(this.lblmedicineid_Click);
            // 
            // btnaddpurchase
            // 
            this.btnaddpurchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnaddpurchase.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddpurchase.ForeColor = System.Drawing.Color.White;
            this.btnaddpurchase.Location = new System.Drawing.Point(197, 58);
            this.btnaddpurchase.Name = "btnaddpurchase";
            this.btnaddpurchase.Size = new System.Drawing.Size(238, 34);
            this.btnaddpurchase.TabIndex = 37;
            this.btnaddpurchase.Text = "Add Purchase";
            this.btnaddpurchase.UseVisualStyleBackColor = false;
            this.btnaddpurchase.Click += new System.EventHandler(this.btnaddpurchase_Click);
            // 
            // btnmanagepurchase
            // 
            this.btnmanagepurchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnmanagepurchase.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanagepurchase.ForeColor = System.Drawing.Color.White;
            this.btnmanagepurchase.Location = new System.Drawing.Point(456, 58);
            this.btnmanagepurchase.Name = "btnmanagepurchase";
            this.btnmanagepurchase.Size = new System.Drawing.Size(238, 34);
            this.btnmanagepurchase.TabIndex = 57;
            this.btnmanagepurchase.Text = "Manage Purchase";
            this.btnmanagepurchase.UseVisualStyleBackColor = false;
            this.btnmanagepurchase.Click += new System.EventHandler(this.btnmanagepurchase_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cash Payment",
            "Bank Payment"});
            this.comboBox1.Location = new System.Drawing.Point(194, 421);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(330, 21);
            this.comboBox1.TabIndex = 58;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 358);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 30);
            this.label1.TabIndex = 59;
            this.label1.Text = "Payment Type\r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(570, 357);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 30);
            this.label2.TabIndex = 60;
            this.label2.Text = "Purchase Date";
            // 
            // txtmedicinename
            // 
            this.txtmedicinename.Location = new System.Drawing.Point(763, 310);
            this.txtmedicinename.Name = "txtmedicinename";
            this.txtmedicinename.Size = new System.Drawing.Size(331, 20);
            this.txtmedicinename.TabIndex = 62;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel2.Location = new System.Drawing.Point(554, 187);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 200);
            this.panel2.TabIndex = 64;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(571, 300);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 30);
            this.label4.TabIndex = 65;
            this.label4.Text = "Medicine Name";
            // 
            // btnupdatepurchase
            // 
            this.btnupdatepurchase.BackColor = System.Drawing.Color.SeaGreen;
            this.btnupdatepurchase.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatepurchase.ForeColor = System.Drawing.Color.White;
            this.btnupdatepurchase.Location = new System.Drawing.Point(722, 58);
            this.btnupdatepurchase.Name = "btnupdatepurchase";
            this.btnupdatepurchase.Size = new System.Drawing.Size(238, 34);
            this.btnupdatepurchase.TabIndex = 89;
            this.btnupdatepurchase.Text = "Update Purchase";
            this.btnupdatepurchase.UseVisualStyleBackColor = false;
            this.btnupdatepurchase.Click += new System.EventHandler(this.btnupdatepurchase_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(573, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 30);
            this.label5.TabIndex = 90;
            this.label5.Text = "Quantity ";
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.Location = new System.Drawing.Point(195, 310);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(331, 20);
            this.txtinvoiceno.TabIndex = 91;
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(764, 244);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(331, 20);
            this.txtquantity.TabIndex = 92;
            // 
            // lblsuppiler
            // 
            this.lblsuppiler.AutoSize = true;
            this.lblsuppiler.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppiler.Location = new System.Drawing.Point(570, 179);
            this.lblsuppiler.Name = "lblsuppiler";
            this.lblsuppiler.Size = new System.Drawing.Size(146, 30);
            this.lblsuppiler.TabIndex = 95;
            this.lblsuppiler.Text = "Price Per Unit";
            // 
            // txtpurchasedate
            // 
            this.txtpurchasedate.Location = new System.Drawing.Point(764, 367);
            this.txtpurchasedate.Name = "txtpurchasedate";
            this.txtpurchasedate.Size = new System.Drawing.Size(331, 20);
            this.txtpurchasedate.TabIndex = 96;
            // 
            // btntotal
            // 
            this.btntotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btntotal.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntotal.ForeColor = System.Drawing.Color.White;
            this.btntotal.Location = new System.Drawing.Point(594, 433);
            this.btntotal.Name = "btntotal";
            this.btntotal.Size = new System.Drawing.Size(122, 34);
            this.btntotal.TabIndex = 97;
            this.btntotal.Text = "Total";
            this.btntotal.UseVisualStyleBackColor = false;
            this.btntotal.Click += new System.EventHandler(this.btnaddinvoice_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(40, 189);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 30);
            this.label6.TabIndex = 100;
            this.label6.Text = "Purchase ID";
            // 
            // txttotal
            // 
            this.txttotal.Location = new System.Drawing.Point(764, 433);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(331, 20);
            this.txttotal.TabIndex = 101;
            // 
            // txtpaymentype
            // 
            this.txtpaymentype.Location = new System.Drawing.Point(196, 368);
            this.txtpaymentype.Name = "txtpaymentype";
            this.txtpaymentype.Size = new System.Drawing.Size(331, 20);
            this.txtpaymentype.TabIndex = 102;
            // 
            // txtpriceperunit
            // 
            this.txtpriceperunit.Location = new System.Drawing.Point(763, 189);
            this.txtpriceperunit.Name = "txtpriceperunit";
            this.txtpriceperunit.Size = new System.Drawing.Size(331, 20);
            this.txtpriceperunit.TabIndex = 103;
            // 
            // update_Purchase1
            // 
            this.update_Purchase1.BackColor = System.Drawing.Color.White;
            this.update_Purchase1.Location = new System.Drawing.Point(-3, 101);
            this.update_Purchase1.Name = "update_Purchase1";
            this.update_Purchase1.Size = new System.Drawing.Size(1104, 672);
            this.update_Purchase1.TabIndex = 99;
            this.update_Purchase1.Load += new System.EventHandler(this.update_Purchase1_Load);
            // 
            // manage_Purchase1
            // 
            this.manage_Purchase1.BackColor = System.Drawing.Color.White;
            this.manage_Purchase1.Location = new System.Drawing.Point(0, 114);
            this.manage_Purchase1.Name = "manage_Purchase1";
            this.manage_Purchase1.Size = new System.Drawing.Size(1086, 570);
            this.manage_Purchase1.TabIndex = 98;
            this.manage_Purchase1.Load += new System.EventHandler(this.manage_Purchase1_Load);
            // 
            // purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.update_Purchase1);
            this.Controls.Add(this.manage_Purchase1);
            this.Controls.Add(this.btntotal);
            this.Controls.Add(this.txtpurchasedate);
            this.Controls.Add(this.lblsuppiler);
            this.Controls.Add(this.txtquantity);
            this.Controls.Add(this.txtinvoiceno);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnupdatepurchase);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtmedicinename);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnmanagepurchase);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.txtsuppiler);
            this.Controls.Add(this.txtpurchaseid);
            this.Controls.Add(this.lblinvoiceno1);
            this.Controls.Add(this.lblmedicineid);
            this.Controls.Add(this.btnaddpurchase);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txttotal);
            this.Controls.Add(this.txtpaymentype);
            this.Controls.Add(this.txtpriceperunit);
            this.Name = "purchase";
            this.Size = new System.Drawing.Size(1104, 770);
            this.Load += new System.EventHandler(this.purchase_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox txtsuppiler;
        private System.Windows.Forms.TextBox txtpurchaseid;
        private System.Windows.Forms.Label lblinvoiceno1;
        private System.Windows.Forms.Label lblmedicineid;
        private System.Windows.Forms.Button btnaddpurchase;
        private System.Windows.Forms.Button btnmanagepurchase;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtmedicinename;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnupdatepurchase;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.Label lblsuppiler;
        private System.Windows.Forms.TextBox txtpurchasedate;
        private System.Windows.Forms.Button btntotal;
        private Manage_Purchase manage_Purchase1;
        private Update_Purchase update_Purchase1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.TextBox txtpaymentype;
        private System.Windows.Forms.TextBox txtpriceperunit;
    }
}
