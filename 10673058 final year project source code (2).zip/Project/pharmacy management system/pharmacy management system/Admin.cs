﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmacy_management_system
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            
            medicine_21.Hide();
            suppiler11.Hide();
            invoice1.Hide();
            purchase1.Hide();
            stock2.Hide();

            dashboard11.Show();
            dashboard11.BringToFront();

        }

        private void btnstock_Click(object sender, EventArgs e)
        {
            invoice1.Hide();
            purchase1.Hide();
            suppiler11.Hide();
            medicine_21.Hide();

            //show current user controls
            stock2.Show();
            stock2.BringToFront();
        }

        private void btnsuppiler_Click(object sender, EventArgs e)
        {
            invoice1.Hide();
            purchase1.Hide();
            stock2.Hide();
            medicine_21.Hide();

            //show current user controls
            suppiler11.Show();
            suppiler11.BringToFront();
        }

        private void btnmedicine_Click(object sender, EventArgs e)
        {


            //hide other usercontrols
            invoice1.Hide();
            purchase1.Hide();
            stock2.Hide();
            suppiler11.Hide();


            //show current user controls
            medicine_21.Show();
            medicine_21.BringToFront();
        }

        private void btninvoice_Click(object sender, EventArgs e)
        {
            medicine_21.Hide();
            suppiler11.Hide();
            purchase1.Hide();
            stock2.Hide();
            dashboard11.Hide();


            // show current user controls
            invoice1.Show();
            invoice1.BringToFront();
        }

        private void btnpurchase_Click(object sender, EventArgs e)
        {

            //hide other usercontrols
            invoice1.Hide();
            suppiler11.Hide();
            stock2.Hide();
            medicine_21.Hide();



            //show current user controls
            purchase1.Show();
            purchase1.BringToFront();

        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            invoice1.Hide();
            purchase1.Hide();
            suppiler11.Hide();
            medicine_21.Hide();

            //show current user controls
            stock2.Show();
            stock2.BringToFront();
            
            
        }
    }
}
