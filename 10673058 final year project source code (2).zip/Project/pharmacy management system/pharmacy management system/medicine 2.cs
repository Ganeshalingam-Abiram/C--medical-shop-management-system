﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class medicine_2 : UserControl
    {



        public medicine_2()
        {
            InitializeComponent();
        }

        private void btnaddmedicine_Click(object sender, EventArgs e)
        {
            update_Medicine1.Hide();
            manage_Medicine1.Hide();



        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtmedicineid.Clear();
            txtmname.Clear();
            txtbuyprice.Clear();
            txtsellprice.Clear();
            txtsuppiler.Clear();
            txtexpireddate.Clear();
            txtmanufacturingdate.Clear();
            txtquantity.Clear();
            txtcategory.Clear();




        }

        private void btnsave_Click(object sender, EventArgs e)

        {
            if (txtmedicineid.Text != "" && txtmname.Text != "" && txtquantity.Text != "" && txtbuyprice.Text != "" && txtsellprice.Text != "" && txtmanufacturingdate.Text != "" && txtexpireddate.Text != "" && txtsuppiler.Text != "" && txtcategory.Text != "")

            {


                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Medicines(Medicine_ID, [Medicine Name],quantity,Category,Suppiler,PurchasePrice,Sellprice,[Manufacturing Date],[Expired Date] )VALUES('" + txtmedicineid.Text + "' , '" + txtmname.Text + "','" + txtquantity.Text + "','" + txtcategory.Text + "','" + txtsuppiler.Text + "','" + txtbuyprice.Text + "' ,'" + txtsellprice.Text + "','" + txtmanufacturingdate.Text + "' ,'" + txtexpireddate.Text + "' )");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Data is insert .", "Information", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            else
            {
                MessageBox.Show("Enter all Data .", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void txttxtmedicinename_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void btnmanagemedicine_Click(object sender, EventArgs e)
        {

        }

        private void btnmanagemedicine_Click_1(object sender, EventArgs e)
        {
            manage_Medicine1.Show();
            update_Medicine1.Hide();

            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Medicines", con);
            DataTable dtb1 = new DataTable();
            sqlDa.Fill(dtb1);





        }

        private void manage_Medicine1_Load(object sender, EventArgs e)
        {

        }

        private void medicine_2_Load(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

        }

        private void btnview_Click(object sender, EventArgs e)
        {
          //  SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            //con.Open();

           // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Suppilerdetails", con);
            //DataTable dtb1 = new DataTable();
           // sqlDa.Fill(dtb1);
           // dataGridView1.DataSource = dtb1;
           // con.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
          //  SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");


           // if (MessageBox.Show("Are you Sure? ", "Delete Confirmation !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {

               // SqlCommand cmd = new SqlCommand();
               // if (dataGridView1.RowCount > 1 && dataGridView1.SelectedRows[0].Index != dataGridView1.RowCount - 1)
                {
                   // cmd.CommandText = "DELETE FROM Suppilerdetails WHERE Medicine_ID =" + dataGridView1.SelectedRows[0].Cells[0].Value + "";
                   // con.Open();
                   // cmd.Connection = con;
                   // cmd.ExecuteNonQuery();
                   // con.Close();
                   // dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                    //MessageBox.Show("Row Deleted");

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void invoice1_Load(object sender, EventArgs e)
        {

        }

        private void btnupdatemedicine_Click(object sender, EventArgs e)
        {
            update_Medicine1.Show();
            manage_Medicine1.Hide();
        }
            
            

        private void update_Medicine1_Load(object sender, EventArgs e)
        {

        }

        private void manage_Medicine1_Load_1(object sender, EventArgs e)
        {

        }
    }
}
