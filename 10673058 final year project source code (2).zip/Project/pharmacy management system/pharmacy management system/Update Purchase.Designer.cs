﻿namespace pharmacy_management_system
{
    partial class Update_Purchase
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btntotal = new System.Windows.Forms.Button();
            this.lblsuppiler = new System.Windows.Forms.Label();
            this.txtpriceperunit = new System.Windows.Forms.TextBox();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtmedicinename = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.txtpurchasedate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.txtsuppiler = new System.Windows.Forms.TextBox();
            this.lblinvoiceno1 = new System.Windows.Forms.Label();
            this.lblmedicineid = new System.Windows.Forms.Label();
            this.txtpurchaseid = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnselect = new System.Windows.Forms.Button();
            this.btnview = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.txtpaymenttype = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btntotal
            // 
            this.btntotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btntotal.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntotal.ForeColor = System.Drawing.Color.White;
            this.btntotal.Location = new System.Drawing.Point(565, 314);
            this.btntotal.Name = "btntotal";
            this.btntotal.Size = new System.Drawing.Size(122, 34);
            this.btntotal.TabIndex = 116;
            this.btntotal.Text = "Total";
            this.btntotal.UseVisualStyleBackColor = false;
            this.btntotal.Click += new System.EventHandler(this.btnaddinvoice_Click);
            // 
            // lblsuppiler
            // 
            this.lblsuppiler.AutoSize = true;
            this.lblsuppiler.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppiler.Location = new System.Drawing.Point(551, 42);
            this.lblsuppiler.Name = "lblsuppiler";
            this.lblsuppiler.Size = new System.Drawing.Size(146, 30);
            this.lblsuppiler.TabIndex = 114;
            this.lblsuppiler.Text = "Price Per Unit";
            // 
            // txtpriceperunit
            // 
            this.txtpriceperunit.Location = new System.Drawing.Point(744, 52);
            this.txtpriceperunit.Name = "txtpriceperunit";
            this.txtpriceperunit.Size = new System.Drawing.Size(331, 20);
            this.txtpriceperunit.TabIndex = 113;
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(743, 118);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(331, 20);
            this.txtquantity.TabIndex = 112;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(573, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 30);
            this.label5.TabIndex = 111;
            this.label5.Text = "Quantity ";
            // 
            // txtmedicinename
            // 
            this.txtmedicinename.FormattingEnabled = true;
            this.txtmedicinename.Items.AddRange(new object[] {
            "Cash Payment",
            "Bank Payment"});
            this.txtmedicinename.Location = new System.Drawing.Point(744, 187);
            this.txtmedicinename.Name = "txtmedicinename";
            this.txtmedicinename.Size = new System.Drawing.Size(330, 21);
            this.txtmedicinename.TabIndex = 110;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(551, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 30);
            this.label4.TabIndex = 109;
            this.label4.Text = "Medicine Name";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel2.Location = new System.Drawing.Point(534, 45);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 270);
            this.panel2.TabIndex = 108;
            // 
            // txttotal
            // 
            this.txttotal.Location = new System.Drawing.Point(744, 325);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(331, 20);
            this.txttotal.TabIndex = 107;
            // 
            // txtpurchasedate
            // 
            this.txtpurchasedate.Location = new System.Drawing.Point(744, 246);
            this.txtpurchasedate.Name = "txtpurchasedate";
            this.txtpurchasedate.Size = new System.Drawing.Size(331, 20);
            this.txtpurchasedate.TabIndex = 106;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(551, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 30);
            this.label2.TabIndex = 104;
            this.label2.Text = "Purchase Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 246);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 30);
            this.label1.TabIndex = 103;
            this.label1.Text = "Payment Type\r\n";
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.Location = new System.Drawing.Point(175, 187);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(331, 20);
            this.txtinvoiceno.TabIndex = 101;
            // 
            // txtsuppiler
            // 
            this.txtsuppiler.Location = new System.Drawing.Point(175, 122);
            this.txtsuppiler.Name = "txtsuppiler";
            this.txtsuppiler.Size = new System.Drawing.Size(331, 20);
            this.txtsuppiler.TabIndex = 100;
            // 
            // lblinvoiceno1
            // 
            this.lblinvoiceno1.AutoSize = true;
            this.lblinvoiceno1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoiceno1.Location = new System.Drawing.Point(47, 177);
            this.lblinvoiceno1.Name = "lblinvoiceno1";
            this.lblinvoiceno1.Size = new System.Drawing.Size(123, 30);
            this.lblinvoiceno1.TabIndex = 99;
            this.lblinvoiceno1.Text = "Invoice_No";
            // 
            // lblmedicineid
            // 
            this.lblmedicineid.AutoSize = true;
            this.lblmedicineid.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicineid.Location = new System.Drawing.Point(44, 112);
            this.lblmedicineid.Name = "lblmedicineid";
            this.lblmedicineid.Size = new System.Drawing.Size(101, 30);
            this.lblmedicineid.TabIndex = 98;
            this.lblmedicineid.Text = "Suppiler ";
            // 
            // txtpurchaseid
            // 
            this.txtpurchaseid.Location = new System.Drawing.Point(176, 52);
            this.txtpurchaseid.Name = "txtpurchaseid";
            this.txtpurchaseid.Size = new System.Drawing.Size(331, 20);
            this.txtpurchaseid.TabIndex = 100;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(44, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 30);
            this.label6.TabIndex = 98;
            this.label6.Text = "Purchase ID";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(36, 430);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1004, 228);
            this.dataGridView1.TabIndex = 117;
            // 
            // btnselect
            // 
            this.btnselect.BackColor = System.Drawing.Color.Navy;
            this.btnselect.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnselect.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnselect.Location = new System.Drawing.Point(868, 378);
            this.btnselect.Name = "btnselect";
            this.btnselect.Size = new System.Drawing.Size(139, 38);
            this.btnselect.TabIndex = 120;
            this.btnselect.Text = "Select";
            this.btnselect.UseVisualStyleBackColor = false;
            this.btnselect.Click += new System.EventHandler(this.btnselect_Click);
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnview.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnview.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnview.Location = new System.Drawing.Point(723, 378);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(139, 38);
            this.btnview.TabIndex = 119;
            this.btnview.Text = "view";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.DarkGreen;
            this.btnupdate.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnupdate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupdate.Location = new System.Drawing.Point(578, 378);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(139, 38);
            this.btnupdate.TabIndex = 118;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // txtpaymenttype
            // 
            this.txtpaymenttype.Location = new System.Drawing.Point(175, 256);
            this.txtpaymenttype.Name = "txtpaymenttype";
            this.txtpaymenttype.Size = new System.Drawing.Size(331, 20);
            this.txtpaymenttype.TabIndex = 121;
            // 
            // Update_Purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.txtpaymenttype);
            this.Controls.Add(this.btnselect);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btntotal);
            this.Controls.Add(this.lblsuppiler);
            this.Controls.Add(this.txtpriceperunit);
            this.Controls.Add(this.txtquantity);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtmedicinename);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txttotal);
            this.Controls.Add(this.txtpurchasedate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtinvoiceno);
            this.Controls.Add(this.txtpurchaseid);
            this.Controls.Add(this.txtsuppiler);
            this.Controls.Add(this.lblinvoiceno1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblmedicineid);
            this.Name = "Update_Purchase";
            this.Size = new System.Drawing.Size(1104, 770);
            this.Load += new System.EventHandler(this.Update_Purchase_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btntotal;
        private System.Windows.Forms.Label lblsuppiler;
        private System.Windows.Forms.TextBox txtpriceperunit;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox txtmedicinename;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.TextBox txtpurchasedate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.TextBox txtsuppiler;
        private System.Windows.Forms.Label lblinvoiceno1;
        private System.Windows.Forms.Label lblmedicineid;
        private System.Windows.Forms.TextBox txtpurchaseid;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnselect;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.TextBox txtpaymenttype;
    }
}
