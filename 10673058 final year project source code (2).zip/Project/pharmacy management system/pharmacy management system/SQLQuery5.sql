USE [pharamacy]
GO

UPDATE [dbo].[Suppilerdetails]
   SET [Suppiler_ID] = <Suppiler_ID, int,>
      ,[Medicine_ID] = <Medicine_ID, int,>
      ,[Suppiler_Name] = <Suppiler_Name, varchar(50),>
      ,[Suppiler_Office _Number] = <Suppiler_Office _Number, varchar(50),>
      ,[Suppiler_Email] = <Suppiler_Email, varchar(50),>
      ,[Sales Rep_ Phone] = <Sales Rep_ Phone, varchar(50),>
      ,[Balance] = <Balance, money,>
 WHERE <Search Conditions,,>
GO


UPDATE Suppilerdetails SET 
[Suppiler_ID] = '77',Medicine_ID = '678',  
 Suppiler_Name = 'etyttttttttttttt', [Suppiler_Office _Number] = '077', 
 Suppiler_Email = 'yui', [Sales Rep_ Phone] = 077, Balance = '90.0000'  where  Suppiler_ID  = 77
