﻿namespace pharmacy_management_system
{
    partial class medicine_2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnreset = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnaddmedicine = new System.Windows.Forms.Button();
            this.btnmanagemedicine = new System.Windows.Forms.Button();
            this.txtmedicineid = new System.Windows.Forms.TextBox();
            this.lblmedicineid = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtbuyprice = new System.Windows.Forms.TextBox();
            this.lblbuyprice = new System.Windows.Forms.Label();
            this.txtsellprice = new System.Windows.Forms.TextBox();
            this.txtmanufacturingdate = new System.Windows.Forms.TextBox();
            this.txtexpireddate = new System.Windows.Forms.TextBox();
            this.lbldetails = new System.Windows.Forms.Label();
            this.lblexpireddate = new System.Windows.Forms.Label();
            this.lblsellprice = new System.Windows.Forms.Label();
            this.txtcategory = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtmname = new System.Windows.Forms.TextBox();
            this.txtsuppiler = new System.Windows.Forms.TextBox();
            this.lblsuppiler = new System.Windows.Forms.Label();
            this.lblmedicinename = new System.Windows.Forms.Label();
            this.btnupdatemedicine = new System.Windows.Forms.Button();
            this.manage_Medicine1 = new pharmacy_management_system.Manage_Medicine();
            this.update_Medicine1 = new pharmacy_management_system.Update_Medicine();
            this.SuspendLayout();
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnreset.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnreset.ForeColor = System.Drawing.Color.White;
            this.btnreset.Location = new System.Drawing.Point(749, 516);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(146, 36);
            this.btnreset.TabIndex = 36;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnsave.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnsave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnsave.Location = new System.Drawing.Point(566, 516);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(146, 36);
            this.btnsave.TabIndex = 35;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnaddmedicine
            // 
            this.btnaddmedicine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnaddmedicine.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddmedicine.ForeColor = System.Drawing.Color.White;
            this.btnaddmedicine.Location = new System.Drawing.Point(412, 2);
            this.btnaddmedicine.Name = "btnaddmedicine";
            this.btnaddmedicine.Size = new System.Drawing.Size(238, 34);
            this.btnaddmedicine.TabIndex = 17;
            this.btnaddmedicine.Text = "Add Medicine";
            this.btnaddmedicine.UseVisualStyleBackColor = false;
            this.btnaddmedicine.Click += new System.EventHandler(this.btnaddmedicine_Click);
            // 
            // btnmanagemedicine
            // 
            this.btnmanagemedicine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnmanagemedicine.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanagemedicine.ForeColor = System.Drawing.Color.White;
            this.btnmanagemedicine.Location = new System.Drawing.Point(156, 2);
            this.btnmanagemedicine.Name = "btnmanagemedicine";
            this.btnmanagemedicine.Size = new System.Drawing.Size(238, 34);
            this.btnmanagemedicine.TabIndex = 19;
            this.btnmanagemedicine.Text = "Manage Medicine";
            this.btnmanagemedicine.UseVisualStyleBackColor = false;
            this.btnmanagemedicine.Click += new System.EventHandler(this.btnmanagemedicine_Click_1);
            // 
            // txtmedicineid
            // 
            this.txtmedicineid.Location = new System.Drawing.Point(156, 127);
            this.txtmedicineid.Name = "txtmedicineid";
            this.txtmedicineid.Size = new System.Drawing.Size(331, 20);
            this.txtmedicineid.TabIndex = 85;
            // 
            // lblmedicineid
            // 
            this.lblmedicineid.AutoSize = true;
            this.lblmedicineid.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicineid.Location = new System.Drawing.Point(154, 99);
            this.lblmedicineid.Name = "lblmedicineid";
            this.lblmedicineid.Size = new System.Drawing.Size(121, 25);
            this.lblmedicineid.TabIndex = 84;
            this.lblmedicineid.Text = "Medicine_ID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel1.Location = new System.Drawing.Point(529, 88);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(4, 500);
            this.panel1.TabIndex = 83;
            // 
            // txtbuyprice
            // 
            this.txtbuyprice.Location = new System.Drawing.Point(564, 127);
            this.txtbuyprice.Name = "txtbuyprice";
            this.txtbuyprice.Size = new System.Drawing.Size(331, 20);
            this.txtbuyprice.TabIndex = 82;
            // 
            // lblbuyprice
            // 
            this.lblbuyprice.AutoSize = true;
            this.lblbuyprice.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbuyprice.Location = new System.Drawing.Point(561, 99);
            this.lblbuyprice.Name = "lblbuyprice";
            this.lblbuyprice.Size = new System.Drawing.Size(136, 25);
            this.lblbuyprice.TabIndex = 81;
            this.lblbuyprice.Text = "PurchasePrice";
            // 
            // txtsellprice
            // 
            this.txtsellprice.Location = new System.Drawing.Point(564, 222);
            this.txtsellprice.Name = "txtsellprice";
            this.txtsellprice.Size = new System.Drawing.Size(331, 20);
            this.txtsellprice.TabIndex = 79;
            // 
            // txtmanufacturingdate
            // 
            this.txtmanufacturingdate.Location = new System.Drawing.Point(564, 323);
            this.txtmanufacturingdate.Name = "txtmanufacturingdate";
            this.txtmanufacturingdate.Size = new System.Drawing.Size(331, 20);
            this.txtmanufacturingdate.TabIndex = 78;
            this.txtmanufacturingdate.Text = "\'YYYY-MM-DD\'";
            // 
            // txtexpireddate
            // 
            this.txtexpireddate.Location = new System.Drawing.Point(564, 424);
            this.txtexpireddate.Name = "txtexpireddate";
            this.txtexpireddate.Size = new System.Drawing.Size(331, 20);
            this.txtexpireddate.TabIndex = 77;
            this.txtexpireddate.Text = "\'YYYY-MM-DD\'";
            // 
            // lbldetails
            // 
            this.lbldetails.AutoSize = true;
            this.lbldetails.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetails.Location = new System.Drawing.Point(564, 295);
            this.lbldetails.Name = "lbldetails";
            this.lbldetails.Size = new System.Drawing.Size(192, 25);
            this.lbldetails.TabIndex = 76;
            this.lbldetails.Text = "Manufacturing Date";
            // 
            // lblexpireddate
            // 
            this.lblexpireddate.AutoSize = true;
            this.lblexpireddate.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexpireddate.Location = new System.Drawing.Point(564, 396);
            this.lblexpireddate.Name = "lblexpireddate";
            this.lblexpireddate.Size = new System.Drawing.Size(126, 25);
            this.lblexpireddate.TabIndex = 75;
            this.lblexpireddate.Text = "Expired Date";
            // 
            // lblsellprice
            // 
            this.lblsellprice.AutoSize = true;
            this.lblsellprice.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsellprice.Location = new System.Drawing.Point(564, 193);
            this.lblsellprice.Name = "lblsellprice";
            this.lblsellprice.Size = new System.Drawing.Size(92, 25);
            this.lblsellprice.TabIndex = 74;
            this.lblsellprice.Text = "Sell price";
            // 
            // txtcategory
            // 
            this.txtcategory.Location = new System.Drawing.Point(156, 426);
            this.txtcategory.Name = "txtcategory";
            this.txtcategory.Size = new System.Drawing.Size(331, 20);
            this.txtcategory.TabIndex = 73;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(156, 398);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 25);
            this.label2.TabIndex = 72;
            this.label2.Text = "Category";
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(156, 323);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(331, 20);
            this.txtquantity.TabIndex = 71;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(154, 295);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 25);
            this.label1.TabIndex = 70;
            this.label1.Text = "Quantity";
            // 
            // txtmname
            // 
            this.txtmname.Location = new System.Drawing.Point(156, 224);
            this.txtmname.Name = "txtmname";
            this.txtmname.Size = new System.Drawing.Size(331, 20);
            this.txtmname.TabIndex = 68;
            // 
            // txtsuppiler
            // 
            this.txtsuppiler.Location = new System.Drawing.Point(156, 527);
            this.txtsuppiler.Name = "txtsuppiler";
            this.txtsuppiler.Size = new System.Drawing.Size(331, 20);
            this.txtsuppiler.TabIndex = 69;
            // 
            // lblsuppiler
            // 
            this.lblsuppiler.AutoSize = true;
            this.lblsuppiler.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppiler.Location = new System.Drawing.Point(159, 499);
            this.lblsuppiler.Name = "lblsuppiler";
            this.lblsuppiler.Size = new System.Drawing.Size(87, 25);
            this.lblsuppiler.TabIndex = 67;
            this.lblsuppiler.Text = "Suppiler";
            // 
            // lblmedicinename
            // 
            this.lblmedicinename.AutoSize = true;
            this.lblmedicinename.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicinename.Location = new System.Drawing.Point(151, 195);
            this.lblmedicinename.Name = "lblmedicinename";
            this.lblmedicinename.Size = new System.Drawing.Size(153, 25);
            this.lblmedicinename.TabIndex = 66;
            this.lblmedicinename.Text = "Medicine_Name";
            // 
            // btnupdatemedicine
            // 
            this.btnupdatemedicine.BackColor = System.Drawing.Color.SeaGreen;
            this.btnupdatemedicine.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatemedicine.ForeColor = System.Drawing.Color.White;
            this.btnupdatemedicine.Location = new System.Drawing.Point(657, 3);
            this.btnupdatemedicine.Name = "btnupdatemedicine";
            this.btnupdatemedicine.Size = new System.Drawing.Size(238, 34);
            this.btnupdatemedicine.TabIndex = 86;
            this.btnupdatemedicine.Text = "Update Medicine";
            this.btnupdatemedicine.UseVisualStyleBackColor = false;
            this.btnupdatemedicine.Click += new System.EventHandler(this.btnupdatemedicine_Click);
            // 
            // manage_Medicine1
            // 
            this.manage_Medicine1.BackColor = System.Drawing.Color.White;
            this.manage_Medicine1.Location = new System.Drawing.Point(3, 43);
            this.manage_Medicine1.Name = "manage_Medicine1";
            this.manage_Medicine1.Size = new System.Drawing.Size(1104, 729);
            this.manage_Medicine1.TabIndex = 88;
            this.manage_Medicine1.Load += new System.EventHandler(this.manage_Medicine1_Load_1);
            // 
            // update_Medicine1
            // 
            this.update_Medicine1.BackColor = System.Drawing.Color.White;
            this.update_Medicine1.Location = new System.Drawing.Point(0, 42);
            this.update_Medicine1.Name = "update_Medicine1";
            this.update_Medicine1.Size = new System.Drawing.Size(1104, 770);
            this.update_Medicine1.TabIndex = 89;
            this.update_Medicine1.Load += new System.EventHandler(this.update_Medicine1_Load);
            // 
            // medicine_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.manage_Medicine1);
            this.Controls.Add(this.update_Medicine1);
            this.Controls.Add(this.btnupdatemedicine);
            this.Controls.Add(this.txtmedicineid);
            this.Controls.Add(this.lblmedicineid);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtbuyprice);
            this.Controls.Add(this.lblbuyprice);
            this.Controls.Add(this.txtsellprice);
            this.Controls.Add(this.txtmanufacturingdate);
            this.Controls.Add(this.txtexpireddate);
            this.Controls.Add(this.lbldetails);
            this.Controls.Add(this.lblexpireddate);
            this.Controls.Add(this.lblsellprice);
            this.Controls.Add(this.txtcategory);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtquantity);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtmname);
            this.Controls.Add(this.txtsuppiler);
            this.Controls.Add(this.lblsuppiler);
            this.Controls.Add(this.lblmedicinename);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btnmanagemedicine);
            this.Controls.Add(this.btnaddmedicine);
            this.Name = "medicine_2";
            this.Size = new System.Drawing.Size(1104, 770);
            this.Load += new System.EventHandler(this.medicine_2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnaddmedicine;
        private System.Windows.Forms.Button btnmanagemedicine;
        private System.Windows.Forms.TextBox txtmedicineid;
        private System.Windows.Forms.Label lblmedicineid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtbuyprice;
        private System.Windows.Forms.Label lblbuyprice;
        private System.Windows.Forms.TextBox txtsellprice;
        private System.Windows.Forms.TextBox txtmanufacturingdate;
        private System.Windows.Forms.TextBox txtexpireddate;
        private System.Windows.Forms.Label lbldetails;
        private System.Windows.Forms.Label lblexpireddate;
        private System.Windows.Forms.Label lblsellprice;
        private System.Windows.Forms.TextBox txtcategory;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtmname;
        private System.Windows.Forms.TextBox txtsuppiler;
        private System.Windows.Forms.Label lblsuppiler;
        private System.Windows.Forms.Label lblmedicinename;
        private System.Windows.Forms.Button btnupdatemedicine;
        private Manage_Medicine manage_Medicine1;
        private Update_Medicine update_Medicine1;
    }
}
