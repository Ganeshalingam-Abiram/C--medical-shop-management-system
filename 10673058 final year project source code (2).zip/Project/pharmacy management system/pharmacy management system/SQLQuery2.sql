USE [pharamacy]
GO

UPDATE [dbo].[Medicines]
   SET [Medicine_ID] = <Medicine_ID, int,>
      ,[Medicine Name] = <Medicine Name, varchar(50),>
      ,[Category] = <Category, varchar(50),>
      ,[Expired Date] = <Expired Date, date,>
      ,[Manufacturing Date] = <Manufacturing Date, date,>
      ,[Suppiler] = <Suppiler, varchar(50),>
      ,[Quantity] = <Quantity, varchar(50),>
      ,[PurchasePrice] = <PurchasePrice, money,>
      ,[Sellprice] = <Sellprice, money,>
 WHERE <Search Conditions,,>
GO


UPDATE  Medicines SET [Medicine Name] = 'dddddy', quantity = 'abi',
 Category = '7/2/2017 12:00:00 AM', Suppiler = '85.0000', 
 [PurchasePrice] = '7/2/1996 12:00:00 AM', 
 Sellprice = 'hjfgdf',[Manufacturing Date] = '54.0000',[Expired Date] = '899999' where Medicine_ID = 89