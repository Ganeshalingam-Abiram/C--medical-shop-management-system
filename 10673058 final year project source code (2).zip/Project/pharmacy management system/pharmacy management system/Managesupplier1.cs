﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class managesupplier1 : UserControl
    {
        public managesupplier1()
        {
            InitializeComponent();
        }

        private void btnview_Click(object sender, EventArgs e)
        {
            {
                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();

                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Suppilerdetails", con);
                DataTable dtb1 = new DataTable();
                sqlDa.Fill(dtb1);
                dataGridViewManagesupplier.DataSource = dtb1;
                con.Close();



           

                
               

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");


            if (MessageBox.Show("Are you Sure? ", "Delete Confirmation !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {

                SqlCommand cmd = new SqlCommand();
                if (dataGridViewManagesupplier.RowCount > 1 && dataGridViewManagesupplier.SelectedRows[0].Index != dataGridViewManagesupplier.RowCount - 1)
                {
                    cmd.CommandText = "DELETE FROM Suppilerdetails WHERE Suppiler_ID =" + dataGridViewManagesupplier.SelectedRows [0].Cells[0].Value + "";
                    con.Open();
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    con.Close();
                    dataGridViewManagesupplier.Rows.RemoveAt(dataGridViewManagesupplier.SelectedRows[0].Index);
                    MessageBox.Show("Row Deleted");

                }
            }
        }

        private void dataGridViewManagesupplier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

