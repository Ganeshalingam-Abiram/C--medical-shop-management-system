﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class Manage_Medicine : UserControl
    {
        public Manage_Medicine()
        {
            InitializeComponent();
        }

        private void btnmanagemedicine_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void Manage_Medicine_Load(object sender, EventArgs e)
        {
            

        }

        private void dataGridViewMedicine_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
               // txtid.Text = row.Cells[0].Value.ToString();
               // txtfname.Text = row.Cells[1].Value.ToString();
               // txtlname.Text = row.Cells[2].Value.ToString();
               // txtcourse.Text = row.Cells[3].Value.ToString();
               // txtgender.Text = row.Cells[4].Value.ToString();
               // txtaddress.Text = row.Cells[5].Value.ToString();
            }
        }

        private void btnview_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Medicines", con);
            DataTable dtb1 = new DataTable();
            sqlDa.Fill(dtb1);
            dataGridView1.DataSource = dtb1;
            con.Close();

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            

            if (MessageBox.Show("Are you Sure? ", "Delete Confirmation !",MessageBoxButtons.YesNo,MessageBoxIcon.Warning )==DialogResult.Yes)
            {

                SqlCommand cmd = new SqlCommand();
                if(dataGridView1.RowCount>1&&dataGridView1.SelectedRows[0].Index!=dataGridView1.RowCount-1)
                {

                    
                    cmd.CommandText = "DELETE FROM Medicines WHERE Medicine_ID =" + dataGridView1.SelectedRows[0].Cells[0].Value + "";
                    con.Open();
                    cmd.Connection = con;
                     cmd.ExecuteNonQuery();
                    con.Close();
                    dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                    MessageBox.Show("Row Deleted");

                }







            }
           
            

           
            }

        private void btnupdate_Click(object sender, EventArgs e)
        {
          
          SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");

            con.Open();


            //  SqlCommand cmd = new SqlCommand("Update Medicines set Name=@Name,Location=@Location Where(Name=@Name)", con);
            // cmd.Parameters.AddWithValue("@Name", txtName.Text);
            // cmd.Parameters.AddWithValue("@Location", txtLocation.Text);
            //cmd.ExecuteNonQuery();
            // MessageBox.Show("updated......");
            // con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

