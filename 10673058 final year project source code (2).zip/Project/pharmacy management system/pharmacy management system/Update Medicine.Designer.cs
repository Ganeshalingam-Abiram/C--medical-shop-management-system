﻿namespace pharmacy_management_system
{
    partial class Update_Medicine
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtcategory = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtmname = new System.Windows.Forms.TextBox();
            this.txtsuppiler = new System.Windows.Forms.TextBox();
            this.lblsuppiler = new System.Windows.Forms.Label();
            this.lblmedicinename = new System.Windows.Forms.Label();
            this.txtPurchasePrice = new System.Windows.Forms.TextBox();
            this.lblPurchasePrice = new System.Windows.Forms.Label();
            this.btnupdate = new System.Windows.Forms.Button();
            this.txtsellprice = new System.Windows.Forms.TextBox();
            this.txtmanufacturingdate = new System.Windows.Forms.TextBox();
            this.txtexpireddate = new System.Windows.Forms.TextBox();
            this.lbldetails = new System.Windows.Forms.Label();
            this.lblexpireddate = new System.Windows.Forms.Label();
            this.lblsellprice = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtmedicineid = new System.Windows.Forms.TextBox();
            this.lblmedicineid = new System.Windows.Forms.Label();
            this.btnview = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnselect = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtcategory
            // 
            this.txtcategory.Location = new System.Drawing.Point(130, 232);
            this.txtcategory.Name = "txtcategory";
            this.txtcategory.Size = new System.Drawing.Size(331, 20);
            this.txtcategory.TabIndex = 52;
            this.txtcategory.TextChanged += new System.EventHandler(this.txtcategory_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(130, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 25);
            this.label2.TabIndex = 51;
            this.label2.Text = "Category";
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(130, 168);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(331, 20);
            this.txtquantity.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(128, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 25);
            this.label1.TabIndex = 49;
            this.label1.Text = "Quantity";
            // 
            // txtmname
            // 
            this.txtmname.Location = new System.Drawing.Point(130, 112);
            this.txtmname.Name = "txtmname";
            this.txtmname.Size = new System.Drawing.Size(331, 20);
            this.txtmname.TabIndex = 47;
            // 
            // txtsuppiler
            // 
            this.txtsuppiler.Location = new System.Drawing.Point(130, 299);
            this.txtsuppiler.Name = "txtsuppiler";
            this.txtsuppiler.Size = new System.Drawing.Size(331, 20);
            this.txtsuppiler.TabIndex = 48;
            this.txtsuppiler.TextChanged += new System.EventHandler(this.txtsuppiler_TextChanged);
            // 
            // lblsuppiler
            // 
            this.lblsuppiler.AutoSize = true;
            this.lblsuppiler.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppiler.Location = new System.Drawing.Point(133, 271);
            this.lblsuppiler.Name = "lblsuppiler";
            this.lblsuppiler.Size = new System.Drawing.Size(87, 25);
            this.lblsuppiler.TabIndex = 46;
            this.lblsuppiler.Text = "Suppiler";
            this.lblsuppiler.Click += new System.EventHandler(this.lblsuppiler_Click);
            // 
            // lblmedicinename
            // 
            this.lblmedicinename.AutoSize = true;
            this.lblmedicinename.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicinename.Location = new System.Drawing.Point(125, 83);
            this.lblmedicinename.Name = "lblmedicinename";
            this.lblmedicinename.Size = new System.Drawing.Size(153, 25);
            this.lblmedicinename.TabIndex = 45;
            this.lblmedicinename.Text = "Medicine_Name";
            // 
            // txtPurchasePrice
            // 
            this.txtPurchasePrice.Location = new System.Drawing.Point(538, 51);
            this.txtPurchasePrice.Name = "txtPurchasePrice";
            this.txtPurchasePrice.Size = new System.Drawing.Size(331, 20);
            this.txtPurchasePrice.TabIndex = 62;
            // 
            // lblPurchasePrice
            // 
            this.lblPurchasePrice.AutoSize = true;
            this.lblPurchasePrice.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchasePrice.Location = new System.Drawing.Point(535, 23);
            this.lblPurchasePrice.Name = "lblPurchasePrice";
            this.lblPurchasePrice.Size = new System.Drawing.Size(136, 25);
            this.lblPurchasePrice.TabIndex = 61;
            this.lblPurchasePrice.Text = "PurchasePrice";
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.DarkGreen;
            this.btnupdate.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnupdate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupdate.Location = new System.Drawing.Point(538, 286);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(139, 38);
            this.btnupdate.TabIndex = 59;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // txtsellprice
            // 
            this.txtsellprice.Location = new System.Drawing.Point(538, 112);
            this.txtsellprice.Name = "txtsellprice";
            this.txtsellprice.Size = new System.Drawing.Size(331, 20);
            this.txtsellprice.TabIndex = 58;
            // 
            // txtmanufacturingdate
            // 
            this.txtmanufacturingdate.Location = new System.Drawing.Point(538, 168);
            this.txtmanufacturingdate.Name = "txtmanufacturingdate";
            this.txtmanufacturingdate.Size = new System.Drawing.Size(331, 20);
            this.txtmanufacturingdate.TabIndex = 57;
            // 
            // txtexpireddate
            // 
            this.txtexpireddate.Location = new System.Drawing.Point(538, 232);
            this.txtexpireddate.Name = "txtexpireddate";
            this.txtexpireddate.Size = new System.Drawing.Size(331, 20);
            this.txtexpireddate.TabIndex = 56;
            // 
            // lbldetails
            // 
            this.lbldetails.AutoSize = true;
            this.lbldetails.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetails.Location = new System.Drawing.Point(538, 140);
            this.lbldetails.Name = "lbldetails";
            this.lbldetails.Size = new System.Drawing.Size(192, 25);
            this.lbldetails.TabIndex = 55;
            this.lbldetails.Text = "Manufacturing Date";
            // 
            // lblexpireddate
            // 
            this.lblexpireddate.AutoSize = true;
            this.lblexpireddate.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexpireddate.Location = new System.Drawing.Point(538, 204);
            this.lblexpireddate.Name = "lblexpireddate";
            this.lblexpireddate.Size = new System.Drawing.Size(126, 25);
            this.lblexpireddate.TabIndex = 54;
            this.lblexpireddate.Text = "Expired Date";
            // 
            // lblsellprice
            // 
            this.lblsellprice.AutoSize = true;
            this.lblsellprice.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsellprice.Location = new System.Drawing.Point(538, 83);
            this.lblsellprice.Name = "lblsellprice";
            this.lblsellprice.Size = new System.Drawing.Size(92, 25);
            this.lblsellprice.TabIndex = 53;
            this.lblsellprice.Text = "Sell price";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel2.Location = new System.Drawing.Point(503, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 300);
            this.panel2.TabIndex = 63;
            // 
            // txtmedicineid
            // 
            this.txtmedicineid.Location = new System.Drawing.Point(130, 51);
            this.txtmedicineid.Name = "txtmedicineid";
            this.txtmedicineid.Size = new System.Drawing.Size(331, 20);
            this.txtmedicineid.TabIndex = 65;
            // 
            // lblmedicineid
            // 
            this.lblmedicineid.AutoSize = true;
            this.lblmedicineid.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicineid.Location = new System.Drawing.Point(128, 23);
            this.lblmedicineid.Name = "lblmedicineid";
            this.lblmedicineid.Size = new System.Drawing.Size(121, 25);
            this.lblmedicineid.TabIndex = 64;
            this.lblmedicineid.Text = "Medicine_ID";
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnview.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnview.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnview.Location = new System.Drawing.Point(683, 286);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(139, 38);
            this.btnview.TabIndex = 67;
            this.btnview.Text = "view";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(44, 342);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1004, 314);
            this.dataGridView1.TabIndex = 66;
            // 
            // btnselect
            // 
            this.btnselect.BackColor = System.Drawing.Color.Navy;
            this.btnselect.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnselect.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnselect.Location = new System.Drawing.Point(828, 286);
            this.btnselect.Name = "btnselect";
            this.btnselect.Size = new System.Drawing.Size(139, 38);
            this.btnselect.TabIndex = 68;
            this.btnselect.Text = "Select";
            this.btnselect.UseVisualStyleBackColor = false;
            this.btnselect.Click += new System.EventHandler(this.btnselect_Click);
            // 
            // Update_Medicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnselect);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtmedicineid);
            this.Controls.Add(this.lblmedicineid);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtPurchasePrice);
            this.Controls.Add(this.lblPurchasePrice);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.txtsellprice);
            this.Controls.Add(this.txtmanufacturingdate);
            this.Controls.Add(this.txtexpireddate);
            this.Controls.Add(this.lbldetails);
            this.Controls.Add(this.lblexpireddate);
            this.Controls.Add(this.lblsellprice);
            this.Controls.Add(this.txtcategory);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtquantity);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtmname);
            this.Controls.Add(this.txtsuppiler);
            this.Controls.Add(this.lblsuppiler);
            this.Controls.Add(this.lblmedicinename);
            this.Name = "Update_Medicine";
            this.Size = new System.Drawing.Size(1104, 770);
            this.Load += new System.EventHandler(this.Update_Medicine_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtcategory;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtmname;
        private System.Windows.Forms.TextBox txtsuppiler;
        private System.Windows.Forms.Label lblsuppiler;
        private System.Windows.Forms.Label lblmedicinename;
        private System.Windows.Forms.TextBox txtPurchasePrice;
        private System.Windows.Forms.Label lblPurchasePrice;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.TextBox txtsellprice;
        private System.Windows.Forms.TextBox txtmanufacturingdate;
        private System.Windows.Forms.TextBox txtexpireddate;
        private System.Windows.Forms.Label lbldetails;
        private System.Windows.Forms.Label lblexpireddate;
        private System.Windows.Forms.Label lblsellprice;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtmedicineid;
        private System.Windows.Forms.Label lblmedicineid;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnselect;
    }
}
