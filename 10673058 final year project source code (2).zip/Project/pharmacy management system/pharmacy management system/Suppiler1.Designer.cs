﻿using System;

namespace pharmacy_management_system
{
    partial class Suppiler1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnreset = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtsuppilernumber = new System.Windows.Forms.TextBox();
            this.txtmedicineid = new System.Windows.Forms.TextBox();
            this.txtbalance = new System.Windows.Forms.TextBox();
            this.txtsalesrepnumber = new System.Windows.Forms.TextBox();
            this.txtsuppileremail = new System.Windows.Forms.TextBox();
            this.txtsuppilername = new System.Windows.Forms.TextBox();
            this.lbldetails = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblsuppiler = new System.Windows.Forms.Label();
            this.lblbuyprice = new System.Windows.Forms.Label();
            this.lblmedicineID = new System.Windows.Forms.Label();
            this.lblsuppilername = new System.Windows.Forms.Label();
            this.btnmanagesuppiler = new System.Windows.Forms.Button();
            this.btnaddmedicine = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.txtsuppilerID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnupdatesuppiler = new System.Windows.Forms.Button();
            this.updateSupplier1 = new pharmacy_management_system.UpdateSupplier();
            this.managesupplier11 = new pharmacy_management_system.managesupplier1();
            this.SuspendLayout();
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnreset.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnreset.ForeColor = System.Drawing.Color.White;
            this.btnreset.Location = new System.Drawing.Point(605, 502);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(146, 36);
            this.btnreset.TabIndex = 53;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel2.Location = new System.Drawing.Point(561, 94);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 500);
            this.panel2.TabIndex = 51;
            // 
            // txtsuppilernumber
            // 
            this.txtsuppilernumber.Location = new System.Drawing.Point(172, 407);
            this.txtsuppilernumber.Name = "txtsuppilernumber";
            this.txtsuppilernumber.Size = new System.Drawing.Size(331, 20);
            this.txtsuppilernumber.TabIndex = 49;
            // 
            // txtmedicineid
            // 
            this.txtmedicineid.Location = new System.Drawing.Point(172, 313);
            this.txtmedicineid.Name = "txtmedicineid";
            this.txtmedicineid.Size = new System.Drawing.Size(331, 20);
            this.txtmedicineid.TabIndex = 48;
            // 
            // txtbalance
            // 
            this.txtbalance.Location = new System.Drawing.Point(606, 326);
            this.txtbalance.Name = "txtbalance";
            this.txtbalance.Size = new System.Drawing.Size(331, 20);
            this.txtbalance.TabIndex = 47;
            // 
            // txtsalesrepnumber
            // 
            this.txtsalesrepnumber.Location = new System.Drawing.Point(606, 234);
            this.txtsalesrepnumber.Name = "txtsalesrepnumber";
            this.txtsalesrepnumber.Size = new System.Drawing.Size(331, 20);
            this.txtsalesrepnumber.TabIndex = 46;
            // 
            // txtsuppileremail
            // 
            this.txtsuppileremail.Location = new System.Drawing.Point(606, 157);
            this.txtsuppileremail.Name = "txtsuppileremail";
            this.txtsuppileremail.Size = new System.Drawing.Size(331, 20);
            this.txtsuppileremail.TabIndex = 50;
            // 
            // txtsuppilername
            // 
            this.txtsuppilername.Location = new System.Drawing.Point(172, 238);
            this.txtsuppilername.Name = "txtsuppilername";
            this.txtsuppilername.Size = new System.Drawing.Size(331, 20);
            this.txtsuppilername.TabIndex = 45;
            // 
            // lbldetails
            // 
            this.lbldetails.AutoSize = true;
            this.lbldetails.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetails.Location = new System.Drawing.Point(603, 293);
            this.lbldetails.Name = "lbldetails";
            this.lbldetails.Size = new System.Drawing.Size(88, 60);
            this.lbldetails.TabIndex = 44;
            this.lbldetails.Text = "Balance\r\n\r\n";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.Location = new System.Drawing.Point(603, 202);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(183, 30);
            this.lblCount.TabIndex = 43;
            this.lblCount.Text = "Sales Rep_ Phone";
            // 
            // lblsuppiler
            // 
            this.lblsuppiler.AutoSize = true;
            this.lblsuppiler.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppiler.Location = new System.Drawing.Point(600, 123);
            this.lblsuppiler.Name = "lblsuppiler";
            this.lblsuppiler.Size = new System.Drawing.Size(157, 30);
            this.lblsuppiler.TabIndex = 42;
            this.lblsuppiler.Text = "Suppiler_Email";
            this.lblsuppiler.Click += new System.EventHandler(this.lblsuppiler_Click);
            // 
            // lblbuyprice
            // 
            this.lblbuyprice.AutoSize = true;
            this.lblbuyprice.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbuyprice.Location = new System.Drawing.Point(167, 374);
            this.lblbuyprice.Name = "lblbuyprice";
            this.lblbuyprice.Size = new System.Drawing.Size(259, 30);
            this.lblbuyprice.TabIndex = 41;
            this.lblbuyprice.Text = "Suppiler_Office _Number\r\n";
            // 
            // lblmedicineID
            // 
            this.lblmedicineID.AutoSize = true;
            this.lblmedicineID.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicineID.Location = new System.Drawing.Point(167, 280);
            this.lblmedicineID.Name = "lblmedicineID";
            this.lblmedicineID.Size = new System.Drawing.Size(134, 30);
            this.lblmedicineID.TabIndex = 40;
            this.lblmedicineID.Text = "Medicine_ID";
            // 
            // lblsuppilername
            // 
            this.lblsuppilername.AutoSize = true;
            this.lblsuppilername.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppilername.Location = new System.Drawing.Point(167, 204);
            this.lblsuppilername.Name = "lblsuppilername";
            this.lblsuppilername.Size = new System.Drawing.Size(162, 30);
            this.lblsuppilername.TabIndex = 39;
            this.lblsuppilername.Text = "Suppiler_Name";
            // 
            // btnmanagesuppiler
            // 
            this.btnmanagesuppiler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnmanagesuppiler.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanagesuppiler.ForeColor = System.Drawing.Color.White;
            this.btnmanagesuppiler.Location = new System.Drawing.Point(548, 14);
            this.btnmanagesuppiler.Name = "btnmanagesuppiler";
            this.btnmanagesuppiler.Size = new System.Drawing.Size(238, 34);
            this.btnmanagesuppiler.TabIndex = 38;
            this.btnmanagesuppiler.Text = "Manage Suppiler";
            this.btnmanagesuppiler.UseVisualStyleBackColor = false;
            this.btnmanagesuppiler.Click += new System.EventHandler(this.btnmanagemedicine_Click);
            // 
            // btnaddmedicine
            // 
            this.btnaddmedicine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnaddmedicine.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddmedicine.ForeColor = System.Drawing.Color.White;
            this.btnaddmedicine.Location = new System.Drawing.Point(277, 14);
            this.btnaddmedicine.Name = "btnaddmedicine";
            this.btnaddmedicine.Size = new System.Drawing.Size(238, 34);
            this.btnaddmedicine.TabIndex = 37;
            this.btnaddmedicine.Text = "Add Suppiler";
            this.btnaddmedicine.UseVisualStyleBackColor = false;
            this.btnaddmedicine.Click += new System.EventHandler(this.btnaddmedicine_Click);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnsave.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnsave.ForeColor = System.Drawing.Color.White;
            this.btnsave.Location = new System.Drawing.Point(345, 502);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(146, 36);
            this.btnsave.TabIndex = 54;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click_1);
            // 
            // txtsuppilerID
            // 
            this.txtsuppilerID.Location = new System.Drawing.Point(172, 157);
            this.txtsuppilerID.Name = "txtsuppilerID";
            this.txtsuppilerID.Size = new System.Drawing.Size(331, 20);
            this.txtsuppilerID.TabIndex = 57;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(167, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 30);
            this.label1.TabIndex = 56;
            this.label1.Text = "Suppiler_ID";
            // 
            // btnupdatesuppiler
            // 
            this.btnupdatesuppiler.BackColor = System.Drawing.Color.SeaGreen;
            this.btnupdatesuppiler.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatesuppiler.ForeColor = System.Drawing.Color.White;
            this.btnupdatesuppiler.Location = new System.Drawing.Point(825, 14);
            this.btnupdatesuppiler.Name = "btnupdatesuppiler";
            this.btnupdatesuppiler.Size = new System.Drawing.Size(238, 34);
            this.btnupdatesuppiler.TabIndex = 58;
            this.btnupdatesuppiler.Text = "Update Suppiler";
            this.btnupdatesuppiler.UseVisualStyleBackColor = false;
            this.btnupdatesuppiler.Click += new System.EventHandler(this.btnupdatesuppiler_Click);
            // 
            // updateSupplier1
            // 
            this.updateSupplier1.BackColor = System.Drawing.Color.White;
            this.updateSupplier1.Location = new System.Drawing.Point(3, 52);
            this.updateSupplier1.Name = "updateSupplier1";
            this.updateSupplier1.Size = new System.Drawing.Size(1101, 691);
            this.updateSupplier1.TabIndex = 59;
            this.updateSupplier1.Load += new System.EventHandler(this.updateSupplier1_Load);
            // 
            // managesupplier11
            // 
            this.managesupplier11.BackColor = System.Drawing.Color.White;
            this.managesupplier11.Location = new System.Drawing.Point(0, 52);
            this.managesupplier11.Name = "managesupplier11";
            this.managesupplier11.Size = new System.Drawing.Size(1098, 728);
            this.managesupplier11.TabIndex = 60;
            this.managesupplier11.Load += new System.EventHandler(this.managesupplier11_Load);
            // 
            // Suppiler1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.updateSupplier1);
            this.Controls.Add(this.managesupplier11);
            this.Controls.Add(this.btnupdatesuppiler);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtsuppilernumber);
            this.Controls.Add(this.txtmedicineid);
            this.Controls.Add(this.txtbalance);
            this.Controls.Add(this.txtsalesrepnumber);
            this.Controls.Add(this.txtsuppileremail);
            this.Controls.Add(this.txtsuppilername);
            this.Controls.Add(this.lbldetails);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.lblsuppiler);
            this.Controls.Add(this.lblbuyprice);
            this.Controls.Add(this.lblmedicineID);
            this.Controls.Add(this.lblsuppilername);
            this.Controls.Add(this.btnmanagesuppiler);
            this.Controls.Add(this.btnaddmedicine);
            this.Controls.Add(this.txtsuppilerID);
            this.Controls.Add(this.label1);
            this.Name = "Suppiler1";
            this.Size = new System.Drawing.Size(1104, 770);
            this.Load += new System.EventHandler(this.Suppiler1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void btnsave_Click(object sender, EventArgs e)
        {

        }

        #endregion

        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtsuppilernumber;
        private System.Windows.Forms.TextBox txtmedicineid;
        private System.Windows.Forms.TextBox txtbalance;
        private System.Windows.Forms.TextBox txtsalesrepnumber;
        private System.Windows.Forms.TextBox txtsuppileremail;
        private System.Windows.Forms.TextBox txtsuppilername;
        private System.Windows.Forms.Label lbldetails;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblsuppiler;
        private System.Windows.Forms.Label lblbuyprice;
        private System.Windows.Forms.Label lblmedicineID;
        private System.Windows.Forms.Label lblsuppilername;
        private System.Windows.Forms.Button btnmanagesuppiler;
        private System.Windows.Forms.Button btnaddmedicine;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox txtsuppilerID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnupdatesuppiler;
        private UpdateSupplier updateSupplier1;
        private managesupplier1 managesupplier11;
    }
}
