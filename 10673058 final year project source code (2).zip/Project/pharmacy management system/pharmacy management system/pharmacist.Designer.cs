﻿namespace pharmacy_management_system
{
    partial class pharmacist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pharmacist));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblAdmin = new System.Windows.Forms.Label();
            this.btndashboard = new System.Windows.Forms.Button();
            this.btnsuppiler = new System.Windows.Forms.Button();
            this.btninvoice = new System.Windows.Forms.Button();
            this.btnpurchase = new System.Windows.Forms.Button();
            this.btnmedicine = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnlogout = new System.Windows.Forms.Button();
            this.purchase2 = new pharmacy_management_system.purchase();
            this.stock1 = new pharmacy_management_system.stock();
            this.purchase1 = new pharmacy_management_system.purchase();
            this.invoice1 = new pharmacy_management_system.invoice();
            this.medicine_21 = new pharmacy_management_system.medicine_2();
            this.suppiler11 = new pharmacy_management_system.Suppiler1();
            this.dashboard11 = new pharmacy_management_system.Dashboard1();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel1.Controls.Add(this.btnlogout);
            this.panel1.Controls.Add(this.lblAdmin);
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.btnsuppiler);
            this.panel1.Controls.Add(this.btninvoice);
            this.panel1.Controls.Add(this.btnpurchase);
            this.panel1.Controls.Add(this.btnmedicine);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(238, 770);
            this.panel1.TabIndex = 1;
            // 
            // lblAdmin
            // 
            this.lblAdmin.AutoSize = true;
            this.lblAdmin.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdmin.ForeColor = System.Drawing.Color.White;
            this.lblAdmin.Location = new System.Drawing.Point(63, 148);
            this.lblAdmin.Name = "lblAdmin";
            this.lblAdmin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblAdmin.Size = new System.Drawing.Size(107, 25);
            this.lblAdmin.TabIndex = 3;
            this.lblAdmin.Text = "Pharmacist";
            // 
            // btndashboard
            // 
            this.btndashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btndashboard.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndashboard.ForeColor = System.Drawing.Color.White;
            this.btndashboard.Location = new System.Drawing.Point(0, 195);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(238, 34);
            this.btndashboard.TabIndex = 2;
            this.btndashboard.Text = "Dashboard";
            this.btndashboard.UseVisualStyleBackColor = false;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // btnsuppiler
            // 
            this.btnsuppiler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnsuppiler.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsuppiler.ForeColor = System.Drawing.Color.White;
            this.btnsuppiler.Location = new System.Drawing.Point(1, 275);
            this.btnsuppiler.Name = "btnsuppiler";
            this.btnsuppiler.Size = new System.Drawing.Size(238, 34);
            this.btnsuppiler.TabIndex = 1;
            this.btnsuppiler.Text = "Suppiler";
            this.btnsuppiler.UseVisualStyleBackColor = false;
            this.btnsuppiler.Click += new System.EventHandler(this.btnsuppiler_Click);
            // 
            // btninvoice
            // 
            this.btninvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btninvoice.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninvoice.ForeColor = System.Drawing.Color.White;
            this.btninvoice.Location = new System.Drawing.Point(1, 315);
            this.btninvoice.Name = "btninvoice";
            this.btninvoice.Size = new System.Drawing.Size(238, 34);
            this.btninvoice.TabIndex = 1;
            this.btninvoice.Text = "Invoice";
            this.btninvoice.UseVisualStyleBackColor = false;
            this.btninvoice.Click += new System.EventHandler(this.btninvoice_Click);
            // 
            // btnpurchase
            // 
            this.btnpurchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnpurchase.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpurchase.ForeColor = System.Drawing.Color.White;
            this.btnpurchase.Location = new System.Drawing.Point(1, 355);
            this.btnpurchase.Name = "btnpurchase";
            this.btnpurchase.Size = new System.Drawing.Size(238, 34);
            this.btnpurchase.TabIndex = 1;
            this.btnpurchase.Text = "Purchase";
            this.btnpurchase.UseVisualStyleBackColor = false;
            this.btnpurchase.Click += new System.EventHandler(this.btnpurchase_Click);
            // 
            // btnmedicine
            // 
            this.btnmedicine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnmedicine.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmedicine.ForeColor = System.Drawing.Color.White;
            this.btnmedicine.Location = new System.Drawing.Point(0, 235);
            this.btnmedicine.Name = "btnmedicine";
            this.btnmedicine.Size = new System.Drawing.Size(238, 34);
            this.btnmedicine.TabIndex = 1;
            this.btnmedicine.Text = "Medicine";
            this.btnmedicine.UseVisualStyleBackColor = false;
            this.btnmedicine.Click += new System.EventHandler(this.btnmedicine_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(42, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 133);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnlogout
            // 
            this.btnlogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnlogout.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.ForeColor = System.Drawing.Color.White;
            this.btnlogout.Location = new System.Drawing.Point(1, 400);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(238, 34);
            this.btnlogout.TabIndex = 5;
            this.btnlogout.Text = "logout";
            this.btnlogout.UseVisualStyleBackColor = false;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // purchase2
            // 
            this.purchase2.BackColor = System.Drawing.Color.White;
            this.purchase2.Location = new System.Drawing.Point(247, 3);
            this.purchase2.Name = "purchase2";
            this.purchase2.Size = new System.Drawing.Size(1104, 770);
            this.purchase2.TabIndex = 7;
            // 
            // stock1
            // 
            this.stock1.BackColor = System.Drawing.Color.White;
            this.stock1.Location = new System.Drawing.Point(247, 2);
            this.stock1.Name = "stock1";
            this.stock1.Size = new System.Drawing.Size(1104, 770);
            this.stock1.TabIndex = 6;
            // 
            // purchase1
            // 
            this.purchase1.BackColor = System.Drawing.Color.White;
            this.purchase1.Location = new System.Drawing.Point(242, 3);
            this.purchase1.Name = "purchase1";
            this.purchase1.Size = new System.Drawing.Size(1104, 770);
            this.purchase1.TabIndex = 5;
            // 
            // invoice1
            // 
            this.invoice1.BackColor = System.Drawing.Color.White;
            this.invoice1.Location = new System.Drawing.Point(241, 3);
            this.invoice1.Name = "invoice1";
            this.invoice1.Size = new System.Drawing.Size(1104, 770);
            this.invoice1.TabIndex = 4;
            // 
            // medicine_21
            // 
            this.medicine_21.BackColor = System.Drawing.Color.White;
            this.medicine_21.Location = new System.Drawing.Point(242, 5);
            this.medicine_21.Name = "medicine_21";
            this.medicine_21.Size = new System.Drawing.Size(1104, 770);
            this.medicine_21.TabIndex = 3;
            // 
            // suppiler11
            // 
            this.suppiler11.BackColor = System.Drawing.Color.White;
            this.suppiler11.Location = new System.Drawing.Point(244, 0);
            this.suppiler11.Name = "suppiler11";
            this.suppiler11.Size = new System.Drawing.Size(1104, 770);
            this.suppiler11.TabIndex = 2;
            // 
            // dashboard11
            // 
            this.dashboard11.BackColor = System.Drawing.Color.White;
            this.dashboard11.Location = new System.Drawing.Point(242, 3);
            this.dashboard11.Name = "dashboard11";
            this.dashboard11.Size = new System.Drawing.Size(1104, 770);
            this.dashboard11.TabIndex = 8;
            // 
            // pharmacist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1380, 770);
            this.Controls.Add(this.dashboard11);
            this.Controls.Add(this.purchase2);
            this.Controls.Add(this.stock1);
            this.Controls.Add(this.purchase1);
            this.Controls.Add(this.invoice1);
            this.Controls.Add(this.medicine_21);
            this.Controls.Add(this.suppiler11);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "pharmacist";
            this.Text = "pharmacist";
            this.Load += new System.EventHandler(this.pharmacist_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblAdmin;
        private System.Windows.Forms.Button btndashboard;
        private System.Windows.Forms.Button btnsuppiler;
        private System.Windows.Forms.Button btninvoice;
        private System.Windows.Forms.Button btnpurchase;
        private System.Windows.Forms.Button btnmedicine;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnlogout;
        private Suppiler1 suppiler11;
        private medicine_2 medicine_21;
        private invoice invoice1;
        private purchase purchase1;
        private stock stock1;
        private purchase purchase2;
        private Dashboard1 dashboard11;
    }
}