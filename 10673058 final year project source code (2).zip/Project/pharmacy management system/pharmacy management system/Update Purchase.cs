﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class Update_Purchase : UserControl
    {
        public Update_Purchase()
        {
            InitializeComponent();
        }

        private void Update_Purchase_Load(object sender, EventArgs e)
        {

        }

        private void btnview_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Purchase", con);
            DataTable dtb1 = new DataTable();
            sqlDa.Fill(dtb1);
            dataGridView1.DataSource = dtb1;
            con.Close();
        }

        private void btnselect_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataReader rdr;
            DataSet ds;
            SqlDataAdapter da;

            if (dataGridView1.RowCount > 1 && dataGridView1.SelectedRows[0].Index != dataGridView1.RowCount - 1)
            {
                cmd.CommandText = "select *  FROM Purchase WHERE Purchase_ID =" + dataGridView1.SelectedRows[0].Cells[0].Value + "";
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();
                bool temp = false;
                while (rdr.Read())
                {

                    String first = rdr.GetValue(0).ToString();
                    txtpurchaseid.Text = first;
                    txtsuppiler.Text = rdr.GetValue(1).ToString();
                    txtinvoiceno.Text = rdr.GetValue(2).ToString();
                    txtpaymenttype.Text = rdr.GetValue(3).ToString();
                    txtpriceperunit.Text = rdr.GetValue(4).ToString();
                    txtquantity.Text = rdr.GetValue(5).ToString(); ;
                    txtmedicinename.Text = rdr.GetValue(6).ToString();
                    txtpurchasedate.Text = rdr.GetValue(7).ToString();
                    txttotal.Text = rdr.GetValue(8).ToString();

                    temp = true;
                }
                if (temp == false)
                    MessageBox.Show("not found");
                con.Close();

            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
           if (txtpurchaseid.Text != "" && txtsuppiler.Text != "" && txtinvoiceno.Text != "" && txtpaymenttype.Text != "" && txtquantity.Text != "" && txtpriceperunit.Text != "" && txtmedicinename.Text != "" && txtpurchasedate.Text != "" && txttotal.Text != "")
                {
                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();

              
                String query = "UPDATE Purchase SET [Purchase_ID] = '" + txtpurchaseid.Text + "',Suppiler = '" + txtsuppiler.Text + "',  Invoice_NO = '" + txtinvoiceno.Text + "', Payment Type = '" + txtpaymenttype.Text + "', quantity = '" + txtquantity.Text + "', [Price Per Unit] = " + txtpriceperunit.Text + ", [Purchase Date] = '" + txtpurchasedate.Text + "' ,Total = " + txttotal.Text + "' where  Purchase_ID   = " + txtpurchaseid.Text;

                Console.WriteLine(query);
                SqlCommand cmd = new SqlCommand(query);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Record Updated Successfully .", "Information", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            else

            {
                MessageBox.Show("Enter all Data .", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnaddinvoice_Click(object sender, EventArgs e)
        {
            double value1 = double.Parse(txtpriceperunit.Text) * double.Parse(txtquantity.Text);


            txttotal.Text = Convert.ToString(value1);
        }
    }
}
