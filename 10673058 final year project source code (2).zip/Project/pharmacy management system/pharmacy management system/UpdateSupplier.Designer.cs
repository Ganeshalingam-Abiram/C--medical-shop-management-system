﻿namespace pharmacy_management_system
{
    partial class UpdateSupplier
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridviewupdatesupplier = new System.Windows.Forms.DataGridView();
            this.txtsuppilerid = new System.Windows.Forms.TextBox();
            this.lblsuppilerid = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtsalesrep_phone = new System.Windows.Forms.TextBox();
            this.lblbuyprice = new System.Windows.Forms.Label();
            this.txtbalance = new System.Windows.Forms.TextBox();
            this.lblsellprice = new System.Windows.Forms.Label();
            this.txtsuppilerofficenumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtsuppilername = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtmedicineid = new System.Windows.Forms.TextBox();
            this.txtsuppileremail = new System.Windows.Forms.TextBox();
            this.lblsuppiler = new System.Windows.Forms.Label();
            this.lblmedicinename = new System.Windows.Forms.Label();
            this.btnselect = new System.Windows.Forms.Button();
            this.btnview = new System.Windows.Forms.Button();
            this.btnupdatesupplier = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridviewupdatesupplier)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridviewupdatesupplier
            // 
            this.dataGridviewupdatesupplier.BackgroundColor = System.Drawing.Color.White;
            this.dataGridviewupdatesupplier.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridviewupdatesupplier.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridviewupdatesupplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridviewupdatesupplier.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridviewupdatesupplier.Location = new System.Drawing.Point(75, 359);
            this.dataGridviewupdatesupplier.Name = "dataGridviewupdatesupplier";
            this.dataGridviewupdatesupplier.Size = new System.Drawing.Size(998, 308);
            this.dataGridviewupdatesupplier.TabIndex = 87;
            this.dataGridviewupdatesupplier.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridviewupdatesupplier_CellContentClick);
            // 
            // txtsuppilerid
            // 
            this.txtsuppilerid.Location = new System.Drawing.Point(196, 69);
            this.txtsuppilerid.Name = "txtsuppilerid";
            this.txtsuppilerid.Size = new System.Drawing.Size(331, 20);
            this.txtsuppilerid.TabIndex = 86;
            this.txtsuppilerid.TextChanged += new System.EventHandler(this.txtsuppilerid_TextChanged);
            // 
            // lblsuppilerid
            // 
            this.lblsuppilerid.AutoSize = true;
            this.lblsuppilerid.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppilerid.Location = new System.Drawing.Point(194, 41);
            this.lblsuppilerid.Name = "lblsuppilerid";
            this.lblsuppilerid.Size = new System.Drawing.Size(115, 25);
            this.lblsuppilerid.TabIndex = 85;
            this.lblsuppilerid.Text = "Suppiler_ID";
            this.lblsuppilerid.Click += new System.EventHandler(this.lblsuppilerid_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel2.Location = new System.Drawing.Point(567, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 300);
            this.panel2.TabIndex = 84;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // txtsalesrep_phone
            // 
            this.txtsalesrep_phone.Location = new System.Drawing.Point(598, 148);
            this.txtsalesrep_phone.Name = "txtsalesrep_phone";
            this.txtsalesrep_phone.Size = new System.Drawing.Size(331, 20);
            this.txtsalesrep_phone.TabIndex = 83;
            this.txtsalesrep_phone.TextChanged += new System.EventHandler(this.txtbuyprice_TextChanged);
            // 
            // lblbuyprice
            // 
            this.lblbuyprice.AutoSize = true;
            this.lblbuyprice.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbuyprice.Location = new System.Drawing.Point(595, 120);
            this.lblbuyprice.Name = "lblbuyprice";
            this.lblbuyprice.Size = new System.Drawing.Size(165, 25);
            this.lblbuyprice.TabIndex = 82;
            this.lblbuyprice.Text = "Sales Rep_ Phone";
            this.lblbuyprice.Click += new System.EventHandler(this.lblbuyprice_Click);
            // 
            // txtbalance
            // 
            this.txtbalance.Location = new System.Drawing.Point(603, 228);
            this.txtbalance.Name = "txtbalance";
            this.txtbalance.Size = new System.Drawing.Size(331, 20);
            this.txtbalance.TabIndex = 80;
            this.txtbalance.TextChanged += new System.EventHandler(this.txtsellprice_TextChanged);
            // 
            // lblsellprice
            // 
            this.lblsellprice.AutoSize = true;
            this.lblsellprice.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsellprice.Location = new System.Drawing.Point(600, 200);
            this.lblsellprice.Name = "lblsellprice";
            this.lblsellprice.Size = new System.Drawing.Size(80, 25);
            this.lblsellprice.TabIndex = 75;
            this.lblsellprice.Text = "Balance";
            this.lblsellprice.Click += new System.EventHandler(this.lblsellprice_Click);
            // 
            // txtsuppilerofficenumber
            // 
            this.txtsuppilerofficenumber.Location = new System.Drawing.Point(196, 308);
            this.txtsuppilerofficenumber.Name = "txtsuppilerofficenumber";
            this.txtsuppilerofficenumber.Size = new System.Drawing.Size(331, 20);
            this.txtsuppilerofficenumber.TabIndex = 74;
            this.txtsuppilerofficenumber.TextChanged += new System.EventHandler(this.txtcategory_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(196, 280);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(234, 25);
            this.label2.TabIndex = 73;
            this.label2.Text = "Suppiler_Office _Number";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtsuppilername
            // 
            this.txtsuppilername.Location = new System.Drawing.Point(196, 228);
            this.txtsuppilername.Name = "txtsuppilername";
            this.txtsuppilername.Size = new System.Drawing.Size(331, 20);
            this.txtsuppilername.TabIndex = 72;
            this.txtsuppilername.TextChanged += new System.EventHandler(this.txtquantity_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(196, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 25);
            this.label1.TabIndex = 71;
            this.label1.Text = "Medicine_ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtmedicineid
            // 
            this.txtmedicineid.Location = new System.Drawing.Point(196, 150);
            this.txtmedicineid.Name = "txtmedicineid";
            this.txtmedicineid.Size = new System.Drawing.Size(331, 20);
            this.txtmedicineid.TabIndex = 69;
            this.txtmedicineid.TextChanged += new System.EventHandler(this.txtmname_TextChanged);
            // 
            // txtsuppileremail
            // 
            this.txtsuppileremail.Location = new System.Drawing.Point(596, 69);
            this.txtsuppileremail.Name = "txtsuppileremail";
            this.txtsuppileremail.Size = new System.Drawing.Size(331, 20);
            this.txtsuppileremail.TabIndex = 70;
            this.txtsuppileremail.TextChanged += new System.EventHandler(this.txtsuppiler_TextChanged);
            // 
            // lblsuppiler
            // 
            this.lblsuppiler.AutoSize = true;
            this.lblsuppiler.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppiler.Location = new System.Drawing.Point(593, 41);
            this.lblsuppiler.Name = "lblsuppiler";
            this.lblsuppiler.Size = new System.Drawing.Size(142, 25);
            this.lblsuppiler.TabIndex = 68;
            this.lblsuppiler.Text = "Suppiler_Email";
            this.lblsuppiler.Click += new System.EventHandler(this.lblsuppiler_Click);
            // 
            // lblmedicinename
            // 
            this.lblmedicinename.AutoSize = true;
            this.lblmedicinename.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicinename.Location = new System.Drawing.Point(194, 200);
            this.lblmedicinename.Name = "lblmedicinename";
            this.lblmedicinename.Size = new System.Drawing.Size(147, 25);
            this.lblmedicinename.TabIndex = 67;
            this.lblmedicinename.Text = "Suppiler_Name";
            this.lblmedicinename.Click += new System.EventHandler(this.lblmedicinename_Click);
            // 
            // btnselect
            // 
            this.btnselect.BackColor = System.Drawing.Color.Navy;
            this.btnselect.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnselect.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnselect.Location = new System.Drawing.Point(886, 289);
            this.btnselect.Name = "btnselect";
            this.btnselect.Size = new System.Drawing.Size(139, 38);
            this.btnselect.TabIndex = 90;
            this.btnselect.Text = "Select";
            this.btnselect.UseVisualStyleBackColor = false;
            this.btnselect.Click += new System.EventHandler(this.btnselect_Click);
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnview.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnview.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnview.Location = new System.Drawing.Point(741, 289);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(139, 38);
            this.btnview.TabIndex = 89;
            this.btnview.Text = "view";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // btnupdatesupplier
            // 
            this.btnupdatesupplier.BackColor = System.Drawing.Color.DarkGreen;
            this.btnupdatesupplier.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnupdatesupplier.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupdatesupplier.Location = new System.Drawing.Point(596, 289);
            this.btnupdatesupplier.Name = "btnupdatesupplier";
            this.btnupdatesupplier.Size = new System.Drawing.Size(139, 38);
            this.btnupdatesupplier.TabIndex = 88;
            this.btnupdatesupplier.Text = "Update";
            this.btnupdatesupplier.UseVisualStyleBackColor = false;
            this.btnupdatesupplier.Click += new System.EventHandler(this.button1_Click);
            // 
            // UpdateSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnselect);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.btnupdatesupplier);
            this.Controls.Add(this.dataGridviewupdatesupplier);
            this.Controls.Add(this.txtsuppilerid);
            this.Controls.Add(this.lblsuppilerid);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtsalesrep_phone);
            this.Controls.Add(this.lblbuyprice);
            this.Controls.Add(this.txtbalance);
            this.Controls.Add(this.lblsellprice);
            this.Controls.Add(this.txtsuppilerofficenumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsuppilername);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtmedicineid);
            this.Controls.Add(this.txtsuppileremail);
            this.Controls.Add(this.lblsuppiler);
            this.Controls.Add(this.lblmedicinename);
            this.Name = "UpdateSupplier";
            this.Size = new System.Drawing.Size(1104, 770);
            this.Load += new System.EventHandler(this.UpdateSupplier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridviewupdatesupplier)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridviewupdatesupplier;
        private System.Windows.Forms.TextBox txtsuppilerid;
        private System.Windows.Forms.Label lblsuppilerid;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtsalesrep_phone;
        private System.Windows.Forms.Label lblbuyprice;
        private System.Windows.Forms.TextBox txtbalance;
        private System.Windows.Forms.Label lblsellprice;
        private System.Windows.Forms.TextBox txtsuppilerofficenumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtsuppilername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtmedicineid;
        private System.Windows.Forms.TextBox txtsuppileremail;
        private System.Windows.Forms.Label lblsuppiler;
        private System.Windows.Forms.Label lblmedicinename;
        private System.Windows.Forms.Button btnselect;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.Button btnupdatesupplier;
    }
}
