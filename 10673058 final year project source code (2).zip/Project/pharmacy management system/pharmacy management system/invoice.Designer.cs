﻿namespace pharmacy_management_system
{
    partial class invoice
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnreset = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtmedicinename = new System.Windows.Forms.TextBox();
            this.txtNoofUnit = new System.Windows.Forms.TextBox();
            this.txtPricePerUnit = new System.Windows.Forms.TextBox();
            this.txtmedicineid = new System.Windows.Forms.TextBox();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblsuppiler = new System.Windows.Forms.Label();
            this.lblmedicinename = new System.Windows.Forms.Label();
            this.lblmedicineid = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtdate = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtInvoice_No = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnupdateinvoice = new System.Windows.Forms.Button();
            this.btnaddinvoice = new System.Windows.Forms.Button();
            this.btnmanageinvoice = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lbltotal = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.update_Invoice1 = new pharmacy_management_system.Update_Invoice();
            this.manageinvoice1 = new pharmacy_management_system.Manageinvoice();
            this.SuspendLayout();
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnreset.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnreset.ForeColor = System.Drawing.Color.White;
            this.btnreset.Location = new System.Drawing.Point(557, 498);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(195, 49);
            this.btnreset.TabIndex = 56;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnsave.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnsave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnsave.Location = new System.Drawing.Point(277, 498);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(213, 49);
            this.btnsave.TabIndex = 55;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel2.Location = new System.Drawing.Point(514, 93);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 270);
            this.panel2.TabIndex = 54;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // txtmedicinename
            // 
            this.txtmedicinename.Location = new System.Drawing.Point(128, 282);
            this.txtmedicinename.Name = "txtmedicinename";
            this.txtmedicinename.Size = new System.Drawing.Size(331, 20);
            this.txtmedicinename.TabIndex = 50;
            this.txtmedicinename.TextChanged += new System.EventHandler(this.txtmedicinename_TextChanged);
            // 
            // txtNoofUnit
            // 
            this.txtNoofUnit.Location = new System.Drawing.Point(553, 210);
            this.txtNoofUnit.Name = "txtNoofUnit";
            this.txtNoofUnit.Size = new System.Drawing.Size(331, 20);
            this.txtNoofUnit.TabIndex = 48;
            this.txtNoofUnit.TextChanged += new System.EventHandler(this.txtNoofUnit_TextChanged);
            // 
            // txtPricePerUnit
            // 
            this.txtPricePerUnit.Location = new System.Drawing.Point(552, 126);
            this.txtPricePerUnit.Name = "txtPricePerUnit";
            this.txtPricePerUnit.Size = new System.Drawing.Size(331, 20);
            this.txtPricePerUnit.TabIndex = 53;
            this.txtPricePerUnit.TextChanged += new System.EventHandler(this.txtPricePerUnit_TextChanged);
            // 
            // txtmedicineid
            // 
            this.txtmedicineid.Location = new System.Drawing.Point(128, 209);
            this.txtmedicineid.Name = "txtmedicineid";
            this.txtmedicineid.Size = new System.Drawing.Size(331, 20);
            this.txtmedicineid.TabIndex = 47;
            this.txtmedicineid.TextChanged += new System.EventHandler(this.txtmedicineid_TextChanged);
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.Location = new System.Drawing.Point(546, 176);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(127, 30);
            this.lblCount.TabIndex = 45;
            this.lblCount.Text = "No of Units";
            this.lblCount.Click += new System.EventHandler(this.lblCount_Click);
            // 
            // lblsuppiler
            // 
            this.lblsuppiler.AutoSize = true;
            this.lblsuppiler.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppiler.Location = new System.Drawing.Point(552, 93);
            this.lblsuppiler.Name = "lblsuppiler";
            this.lblsuppiler.Size = new System.Drawing.Size(146, 30);
            this.lblsuppiler.TabIndex = 44;
            this.lblsuppiler.Text = "Price Per Unit";
            this.lblsuppiler.Click += new System.EventHandler(this.lblsuppiler_Click);
            // 
            // lblmedicinename
            // 
            this.lblmedicinename.AutoSize = true;
            this.lblmedicinename.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicinename.Location = new System.Drawing.Point(123, 249);
            this.lblmedicinename.Name = "lblmedicinename";
            this.lblmedicinename.Size = new System.Drawing.Size(170, 30);
            this.lblmedicinename.TabIndex = 41;
            this.lblmedicinename.Text = "Medicine_Name";
            this.lblmedicinename.Click += new System.EventHandler(this.lblmedicinename_Click);
            // 
            // lblmedicineid
            // 
            this.lblmedicineid.AutoSize = true;
            this.lblmedicineid.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicineid.Location = new System.Drawing.Point(123, 176);
            this.lblmedicineid.Name = "lblmedicineid";
            this.lblmedicineid.Size = new System.Drawing.Size(134, 30);
            this.lblmedicineid.TabIndex = 40;
            this.lblmedicineid.Text = "Medicine_ID";
            this.lblmedicineid.Click += new System.EventHandler(this.lblmedicineid_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(123, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 30);
            this.label1.TabIndex = 40;
            this.label1.Text = "Date";
            this.label1.Click += new System.EventHandler(this.lblmedicineid_Click);
            // 
            // txtdate
            // 
            this.txtdate.Location = new System.Drawing.Point(130, 363);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(331, 20);
            this.txtdate.TabIndex = 47;
            this.txtdate.Text = "\'YYYY-MM-DD\'";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(159, 453);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 57;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // txtInvoice_No
            // 
            this.txtInvoice_No.Location = new System.Drawing.Point(128, 126);
            this.txtInvoice_No.Name = "txtInvoice_No";
            this.txtInvoice_No.Size = new System.Drawing.Size(331, 20);
            this.txtInvoice_No.TabIndex = 59;
            this.txtInvoice_No.TextChanged += new System.EventHandler(this.txtInvoice_No_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(123, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 30);
            this.label2.TabIndex = 58;
            this.label2.Text = "Invoice_NO";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnupdateinvoice
            // 
            this.btnupdateinvoice.BackColor = System.Drawing.Color.SeaGreen;
            this.btnupdateinvoice.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdateinvoice.ForeColor = System.Drawing.Color.White;
            this.btnupdateinvoice.Location = new System.Drawing.Point(616, 3);
            this.btnupdateinvoice.Name = "btnupdateinvoice";
            this.btnupdateinvoice.Size = new System.Drawing.Size(238, 34);
            this.btnupdateinvoice.TabIndex = 88;
            this.btnupdateinvoice.Text = "Update Invoice";
            this.btnupdateinvoice.UseVisualStyleBackColor = false;
            this.btnupdateinvoice.Click += new System.EventHandler(this.btnupdateinvoice_Click);
            // 
            // btnaddinvoice
            // 
            this.btnaddinvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnaddinvoice.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddinvoice.ForeColor = System.Drawing.Color.White;
            this.btnaddinvoice.Location = new System.Drawing.Point(128, 3);
            this.btnaddinvoice.Name = "btnaddinvoice";
            this.btnaddinvoice.Size = new System.Drawing.Size(238, 34);
            this.btnaddinvoice.TabIndex = 87;
            this.btnaddinvoice.Text = "Add Invoice";
            this.btnaddinvoice.UseVisualStyleBackColor = false;
            this.btnaddinvoice.Click += new System.EventHandler(this.btnaddinvoice_Click);
            // 
            // btnmanageinvoice
            // 
            this.btnmanageinvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnmanageinvoice.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmanageinvoice.ForeColor = System.Drawing.Color.White;
            this.btnmanageinvoice.Location = new System.Drawing.Point(372, 3);
            this.btnmanageinvoice.Name = "btnmanageinvoice";
            this.btnmanageinvoice.Size = new System.Drawing.Size(238, 34);
            this.btnmanageinvoice.TabIndex = 89;
            this.btnmanageinvoice.Text = "Manage Invoice";
            this.btnmanageinvoice.UseVisualStyleBackColor = false;
            this.btnmanageinvoice.Click += new System.EventHandler(this.btnmanageinvoice_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(523, 283);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 34);
            this.button1.TabIndex = 90;
            this.button1.Text = "Total Price ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbltotal.Location = new System.Drawing.Point(755, 343);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(0, 25);
            this.lbltotal.TabIndex = 93;
            this.lbltotal.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(719, 283);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(135, 20);
            this.txtTotal.TabIndex = 94;
            // 
            // update_Invoice1
            // 
            this.update_Invoice1.BackColor = System.Drawing.Color.White;
            this.update_Invoice1.Location = new System.Drawing.Point(19, 50);
            this.update_Invoice1.Name = "update_Invoice1";
            this.update_Invoice1.Size = new System.Drawing.Size(1104, 770);
            this.update_Invoice1.TabIndex = 92;
            this.update_Invoice1.Load += new System.EventHandler(this.update_Invoice1_Load);
            // 
            // manageinvoice1
            // 
            this.manageinvoice1.BackColor = System.Drawing.Color.White;
            this.manageinvoice1.Location = new System.Drawing.Point(23, 50);
            this.manageinvoice1.Name = "manageinvoice1";
            this.manageinvoice1.Size = new System.Drawing.Size(1069, 766);
            this.manageinvoice1.TabIndex = 91;
            // 
            // invoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.update_Invoice1);
            this.Controls.Add(this.manageinvoice1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnmanageinvoice);
            this.Controls.Add(this.btnupdateinvoice);
            this.Controls.Add(this.btnaddinvoice);
            this.Controls.Add(this.txtInvoice_No);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtmedicinename);
            this.Controls.Add(this.txtNoofUnit);
            this.Controls.Add(this.txtPricePerUnit);
            this.Controls.Add(this.txtdate);
            this.Controls.Add(this.txtmedicineid);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.lblsuppiler);
            this.Controls.Add(this.lblmedicinename);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblmedicineid);
            this.Controls.Add(this.txtTotal);
            this.Name = "invoice";
            this.Size = new System.Drawing.Size(1104, 770);
            this.Load += new System.EventHandler(this.invoice_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtmedicinename;
        private System.Windows.Forms.TextBox txtNoofUnit;
        private System.Windows.Forms.TextBox txtPricePerUnit;
        private System.Windows.Forms.TextBox txtmedicineid;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblsuppiler;
        private System.Windows.Forms.Label lblmedicinename;
        private System.Windows.Forms.Label lblmedicineid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdate;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtInvoice_No;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnupdateinvoice;
        private System.Windows.Forms.Button btnaddinvoice;
        private System.Windows.Forms.Button btnmanageinvoice;
        private System.Windows.Forms.Button button1;
        private Manageinvoice manageinvoice1;
        private Update_Invoice update_Invoice1;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.TextBox txtTotal;
    }
}
