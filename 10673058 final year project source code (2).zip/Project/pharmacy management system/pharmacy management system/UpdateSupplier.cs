﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class UpdateSupplier : UserControl
    {
        public UpdateSupplier()
        {
            InitializeComponent();
        }

        private void UpdateSupplier_Load(object sender, EventArgs e)
        {

        }

        private void txtsuppilerid_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblsuppilerid_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtbuyprice_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblbuyprice_Click(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

        }

        private void txtsellprice_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblsellprice_Click(object sender, EventArgs e)
        {

        }

        private void txtcategory_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtquantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtmname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtsuppiler_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblsuppiler_Click(object sender, EventArgs e)
        {

        }

        private void lblmedicinename_Click(object sender, EventArgs e)
        {

        }

        private void btnview_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Suppilerdetails", con);
            DataTable dtb1 = new DataTable();
            sqlDa.Fill(dtb1);
            dataGridviewupdatesupplier.DataSource = dtb1;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtsuppilerid.Text != "" && txtmedicineid.Text != "" && txtsuppilername.Text != "" && txtsuppilerofficenumber.Text != "" && txtsuppileremail.Text != "" && txtsalesrep_phone.Text != "" && txtbalance.Text != "")
            {

                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();

                
                String query = "UPDATE Suppilerdetails SET [Suppiler_ID] = '" + txtsuppilerid.Text + "',Medicine_ID = '" + txtmedicineid.Text + "',   Suppiler_Name = '" + txtsuppilername.Text + "', [Suppiler_Office _Number] = '" + txtsuppilerofficenumber.Text + "', Suppiler_Email = '" + txtsuppileremail.Text + "', [Sales Rep_ Phone] = " + txtsalesrep_phone.Text + ", Balance = '" + txtbalance.Text + "'  where  Suppiler_ID  = " + txtsuppilerid.Text;

                Console.WriteLine(query);
                SqlCommand cmd = new SqlCommand(query);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Record Updated Successfully .", "Information", MessageBoxButtons.OK, MessageBoxIcon.None);
            }



            else

            {
                MessageBox.Show("Enter all Data .", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnselect_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataReader rdr;
            DataSet ds;
            SqlDataAdapter da;

            if (dataGridviewupdatesupplier.RowCount > 1 && dataGridviewupdatesupplier.SelectedRows[0].Index != dataGridviewupdatesupplier.RowCount - 1)
            {
                cmd.CommandText = "select *  FROM Suppilerdetails WHERE Suppiler_ID =" + dataGridviewupdatesupplier.SelectedRows[0].Cells[0].Value + "";
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();
                bool temp = false;
                while (rdr.Read())
                {

                    String first = rdr.GetValue(0).ToString();
                    txtsuppilerid.Text = first;
                    txtmedicineid.Text = rdr.GetValue(1).ToString();
                    txtsuppilername.Text = rdr.GetValue(2).ToString();
                    txtsuppilerofficenumber.Text = rdr.GetValue(3).ToString();
                    txtsuppileremail.Text = rdr.GetValue(4).ToString();
                    txtsalesrep_phone.Text = rdr.GetValue(5).ToString(); ;
                    txtbalance.Text = rdr.GetValue(6).ToString();
                 

                    temp = true;
                }
                if (temp == false)
                    MessageBox.Show("not found");
                con.Close();


            }
        }

        private void dataGridviewupdatesupplier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
