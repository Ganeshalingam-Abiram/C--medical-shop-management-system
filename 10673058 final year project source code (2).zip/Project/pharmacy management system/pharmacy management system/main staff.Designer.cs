﻿namespace pharmacy_management_system
{
    partial class main_staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main_staff));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnlogout = new System.Windows.Forms.Button();
            this.lblAdmin = new System.Windows.Forms.Label();
            this.btndashboard = new System.Windows.Forms.Button();
            this.btninvoice = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnmedicine = new System.Windows.Forms.Button();
            this.medicine_21 = new pharmacy_management_system.medicine_2();
            this.invoice1 = new pharmacy_management_system.invoice();
            this.stock1 = new pharmacy_management_system.stock();
            this.dashboard11 = new pharmacy_management_system.Dashboard1();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel1.Controls.Add(this.btnmedicine);
            this.panel1.Controls.Add(this.btnlogout);
            this.panel1.Controls.Add(this.lblAdmin);
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.btninvoice);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(238, 770);
            this.panel1.TabIndex = 4;
            // 
            // btnlogout
            // 
            this.btnlogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnlogout.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.ForeColor = System.Drawing.Color.White;
            this.btnlogout.Location = new System.Drawing.Point(0, 315);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(238, 34);
            this.btnlogout.TabIndex = 4;
            this.btnlogout.Text = "logout";
            this.btnlogout.UseVisualStyleBackColor = false;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // lblAdmin
            // 
            this.lblAdmin.AutoSize = true;
            this.lblAdmin.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdmin.ForeColor = System.Drawing.Color.White;
            this.lblAdmin.Location = new System.Drawing.Point(84, 148);
            this.lblAdmin.Name = "lblAdmin";
            this.lblAdmin.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblAdmin.Size = new System.Drawing.Size(53, 25);
            this.lblAdmin.TabIndex = 3;
            this.lblAdmin.Text = "Staff";
            // 
            // btndashboard
            // 
            this.btndashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btndashboard.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndashboard.ForeColor = System.Drawing.Color.White;
            this.btndashboard.Location = new System.Drawing.Point(0, 195);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(238, 34);
            this.btndashboard.TabIndex = 2;
            this.btndashboard.Text = "Dashboard";
            this.btndashboard.UseVisualStyleBackColor = false;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // btninvoice
            // 
            this.btninvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btninvoice.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninvoice.ForeColor = System.Drawing.Color.White;
            this.btninvoice.Location = new System.Drawing.Point(0, 275);
            this.btninvoice.Name = "btninvoice";
            this.btninvoice.Size = new System.Drawing.Size(238, 34);
            this.btninvoice.TabIndex = 1;
            this.btninvoice.Text = "Invoice";
            this.btninvoice.UseVisualStyleBackColor = false;
            this.btninvoice.Click += new System.EventHandler(this.btninvoice_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(42, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 133);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnmedicine
            // 
            this.btnmedicine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnmedicine.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmedicine.ForeColor = System.Drawing.Color.White;
            this.btnmedicine.Location = new System.Drawing.Point(0, 235);
            this.btnmedicine.Name = "btnmedicine";
            this.btnmedicine.Size = new System.Drawing.Size(238, 34);
            this.btnmedicine.TabIndex = 5;
            this.btnmedicine.Text = "Medicine";
            this.btnmedicine.UseVisualStyleBackColor = false;
            this.btnmedicine.Click += new System.EventHandler(this.btnmedicine_Click);
            // 
            // medicine_21
            // 
            this.medicine_21.BackColor = System.Drawing.Color.White;
            this.medicine_21.Location = new System.Drawing.Point(244, 3);
            this.medicine_21.Name = "medicine_21";
            this.medicine_21.Size = new System.Drawing.Size(1104, 770);
            this.medicine_21.TabIndex = 5;
            // 
            // invoice1
            // 
            this.invoice1.BackColor = System.Drawing.Color.White;
            this.invoice1.Location = new System.Drawing.Point(244, 3);
            this.invoice1.Name = "invoice1";
            this.invoice1.Size = new System.Drawing.Size(1104, 770);
            this.invoice1.TabIndex = 6;
            // 
            // stock1
            // 
            this.stock1.BackColor = System.Drawing.Color.White;
            this.stock1.Location = new System.Drawing.Point(243, 3);
            this.stock1.Name = "stock1";
            this.stock1.Size = new System.Drawing.Size(1104, 770);
            this.stock1.TabIndex = 7;
            // 
            // dashboard11
            // 
            this.dashboard11.BackColor = System.Drawing.Color.White;
            this.dashboard11.Location = new System.Drawing.Point(245, 6);
            this.dashboard11.Name = "dashboard11";
            this.dashboard11.Size = new System.Drawing.Size(1104, 770);
            this.dashboard11.TabIndex = 8;
            // 
            // main_staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1380, 770);
            this.Controls.Add(this.dashboard11);
            this.Controls.Add(this.stock1);
            this.Controls.Add(this.invoice1);
            this.Controls.Add(this.medicine_21);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "main_staff";
            this.Text = "main_staff";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblAdmin;
        private System.Windows.Forms.Button btndashboard;
        private System.Windows.Forms.Button btninvoice;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Button btnmedicine;
        private medicine_2 medicine_21;
        private invoice invoice1;
        private stock stock1;
        private Dashboard1 dashboard11;
    }
}