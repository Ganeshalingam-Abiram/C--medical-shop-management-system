﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class Update_Medicine : UserControl
    {
        public Update_Medicine()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtmedicineid.Text != "" && txtmname.Text != "" && txtquantity.Text != "" && txtPurchasePrice.Text != "" && txtsellprice.Text != "" && txtmanufacturingdate.Text != "" && txtexpireddate.Text != "" && txtsuppiler.Text != "" && txtcategory.Text != "")

            {
                SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
                con.Open();

                String query = "UPDATE  Medicines SET [Medicine Name] = '" + txtmname.Text +"', quantity = '"+ txtquantity.Text + "', Category = '" + txtcategory.Text + "', Suppiler = '" + txtsuppiler.Text + "', Purchaseprice = " + txtPurchasePrice.Text + ", Sellprice = " + txtsellprice.Text + ",[Manufacturing Date] = '" + txtmanufacturingdate.Text + "',[Expired Date] = '" + txtexpireddate.Text + "' where Medicine_ID = "+ txtmedicineid.Text;

                Console.WriteLine(query);
                SqlCommand cmd = new SqlCommand(query);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Record Updated Successfully .", "Information", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            else

            {
                MessageBox.Show("Enter all Data .", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
            

        private void txtcategory_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtsuppiler_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblsuppiler_Click(object sender, EventArgs e)
        {

        }

        private void Update_Medicine_Load(object sender, EventArgs e)
        {

        }

        private void btnview_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * from Medicines", con);
            DataTable dtb1 = new DataTable();
            sqlDa.Fill(dtb1);
            dataGridView1.DataSource = dtb1;
            con.Close();

        }

        private void btnselect_Click(object sender, EventArgs e)
        {





            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataReader rdr;
            DataSet ds;
            SqlDataAdapter da;

            if (dataGridView1.RowCount > 1 && dataGridView1.SelectedRows[0].Index != dataGridView1.RowCount - 1)
            {
                cmd.CommandText = "select *  FROM Medicines WHERE Medicine_ID =" + dataGridView1.SelectedRows[0].Cells[0].Value + "";
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();
                bool temp = false;
                while (rdr.Read())
                {
                   
                    String first = rdr.GetValue(0).ToString();
                    txtmedicineid.Text = first;
                    txtmname.Text = rdr.GetValue(1).ToString();
                    txtquantity.Text = rdr.GetValue(6).ToString();
                    txtcategory.Text = rdr.GetValue(2).ToString();
                    txtsuppiler.Text = rdr.GetValue(5).ToString();
                    txtPurchasePrice.Text = rdr.GetValue(7).ToString(); ;
                    txtsellprice.Text = rdr.GetValue(8).ToString(); 
                    txtmanufacturingdate.Text = rdr.GetValue(4).ToString();
                    txtexpireddate.Text = rdr.GetValue(3).ToString();

                    temp = true;
                }
                if (temp == false)
                    MessageBox.Show("not found");
                con.Close();


            }
        }
    }
    }

