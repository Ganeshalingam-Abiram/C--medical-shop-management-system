﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pharmacy_management_system
{
    public partial class Dashboard1 : UserControl
    {
        public Dashboard1()
        {
            InitializeComponent();
        }

        private void Dashboard1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnexpireddate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source =MATHAVAN\SQLEXPRESS;Initial Catalog=pharamacy;User ID=sa;Password=1qaz2wsx@");
            con.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("select  [Medicine Name]  ,[Expired Date] ,[Manufacturing Date],[Suppiler] from Medicines where [Expired Date] <  GETDATE()", con);
            DataTable dtb1 = new DataTable();
            sqlDa.Fill(dtb1);
            dataGridView1.DataSource = dtb1;
            con.Close();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtmedicine_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
