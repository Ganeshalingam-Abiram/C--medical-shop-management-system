﻿namespace pharmacy_management_system
{
    partial class Update_Invoice
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button1 = new System.Windows.Forms.Button();
            this.txtInvoice_No = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtmedicinename = new System.Windows.Forms.TextBox();
            this.txttotalprice = new System.Windows.Forms.TextBox();
            this.txtNoofUnit = new System.Windows.Forms.TextBox();
            this.txtPricePerUnit = new System.Windows.Forms.TextBox();
            this.txtdate = new System.Windows.Forms.TextBox();
            this.txtmedicineid = new System.Windows.Forms.TextBox();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblsuppiler = new System.Windows.Forms.Label();
            this.lblmedicinename = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblmedicineid = new System.Windows.Forms.Label();
            this.btnupdatesupplier = new System.Windows.Forms.Button();
            this.btnview = new System.Windows.Forms.Button();
            this.btnselect = new System.Windows.Forms.Button();
            this.dataGridviewupdateinvoice = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridviewupdateinvoice)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(546, 230);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 34);
            this.button1.TabIndex = 107;
            this.button1.Text = "Total Price ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtInvoice_No
            // 
            this.txtInvoice_No.Location = new System.Drawing.Point(140, 73);
            this.txtInvoice_No.Name = "txtInvoice_No";
            this.txtInvoice_No.Size = new System.Drawing.Size(331, 20);
            this.txtInvoice_No.TabIndex = 106;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(135, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 30);
            this.label2.TabIndex = 105;
            this.label2.Text = "Invoice_NO";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.panel2.Location = new System.Drawing.Point(526, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(4, 340);
            this.panel2.TabIndex = 102;
            // 
            // txtmedicinename
            // 
            this.txtmedicinename.Location = new System.Drawing.Point(140, 242);
            this.txtmedicinename.Name = "txtmedicinename";
            this.txtmedicinename.Size = new System.Drawing.Size(331, 20);
            this.txtmedicinename.TabIndex = 100;
            // 
            // txttotalprice
            // 
            this.txttotalprice.Location = new System.Drawing.Point(756, 230);
            this.txttotalprice.Multiline = true;
            this.txttotalprice.Name = "txttotalprice";
            this.txttotalprice.Size = new System.Drawing.Size(194, 34);
            this.txttotalprice.TabIndex = 99;
            this.txttotalprice.TextChanged += new System.EventHandler(this.txttotalprice_TextChanged);
            // 
            // txtNoofUnit
            // 
            this.txtNoofUnit.Location = new System.Drawing.Point(565, 157);
            this.txtNoofUnit.Name = "txtNoofUnit";
            this.txtNoofUnit.Size = new System.Drawing.Size(331, 20);
            this.txtNoofUnit.TabIndex = 98;
            // 
            // txtPricePerUnit
            // 
            this.txtPricePerUnit.Location = new System.Drawing.Point(564, 73);
            this.txtPricePerUnit.Name = "txtPricePerUnit";
            this.txtPricePerUnit.Size = new System.Drawing.Size(331, 20);
            this.txtPricePerUnit.TabIndex = 101;
            // 
            // txtdate
            // 
            this.txtdate.Location = new System.Drawing.Point(142, 338);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(331, 20);
            this.txtdate.TabIndex = 97;
            this.txtdate.TextChanged += new System.EventHandler(this.txtdate_TextChanged);
            // 
            // txtmedicineid
            // 
            this.txtmedicineid.Location = new System.Drawing.Point(140, 156);
            this.txtmedicineid.Name = "txtmedicineid";
            this.txtmedicineid.Size = new System.Drawing.Size(331, 20);
            this.txtmedicineid.TabIndex = 96;
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.Location = new System.Drawing.Point(558, 123);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(127, 30);
            this.lblCount.TabIndex = 95;
            this.lblCount.Text = "No of Units";
            // 
            // lblsuppiler
            // 
            this.lblsuppiler.AutoSize = true;
            this.lblsuppiler.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuppiler.Location = new System.Drawing.Point(564, 40);
            this.lblsuppiler.Name = "lblsuppiler";
            this.lblsuppiler.Size = new System.Drawing.Size(146, 30);
            this.lblsuppiler.TabIndex = 94;
            this.lblsuppiler.Text = "Price Per Unit";
            // 
            // lblmedicinename
            // 
            this.lblmedicinename.AutoSize = true;
            this.lblmedicinename.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicinename.Location = new System.Drawing.Point(135, 208);
            this.lblmedicinename.Name = "lblmedicinename";
            this.lblmedicinename.Size = new System.Drawing.Size(170, 30);
            this.lblmedicinename.TabIndex = 93;
            this.lblmedicinename.Text = "Medicine_Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(139, 305);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 30);
            this.label1.TabIndex = 92;
            this.label1.Text = "Date";
            // 
            // lblmedicineid
            // 
            this.lblmedicineid.AutoSize = true;
            this.lblmedicineid.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedicineid.Location = new System.Drawing.Point(135, 123);
            this.lblmedicineid.Name = "lblmedicineid";
            this.lblmedicineid.Size = new System.Drawing.Size(134, 30);
            this.lblmedicineid.TabIndex = 91;
            this.lblmedicineid.Text = "Medicine_ID";
            // 
            // btnupdatesupplier
            // 
            this.btnupdatesupplier.BackColor = System.Drawing.Color.DarkGreen;
            this.btnupdatesupplier.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnupdatesupplier.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupdatesupplier.Location = new System.Drawing.Point(546, 325);
            this.btnupdatesupplier.Name = "btnupdatesupplier";
            this.btnupdatesupplier.Size = new System.Drawing.Size(139, 38);
            this.btnupdatesupplier.TabIndex = 110;
            this.btnupdatesupplier.Text = "Update";
            this.btnupdatesupplier.UseVisualStyleBackColor = false;
            this.btnupdatesupplier.Click += new System.EventHandler(this.btnupdatesupplier_Click);
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            this.btnview.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnview.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnview.Location = new System.Drawing.Point(704, 325);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(139, 38);
            this.btnview.TabIndex = 111;
            this.btnview.Text = "view";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // btnselect
            // 
            this.btnselect.BackColor = System.Drawing.Color.Navy;
            this.btnselect.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnselect.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnselect.Location = new System.Drawing.Point(860, 325);
            this.btnselect.Name = "btnselect";
            this.btnselect.Size = new System.Drawing.Size(139, 38);
            this.btnselect.TabIndex = 112;
            this.btnselect.Text = "Select";
            this.btnselect.UseVisualStyleBackColor = false;
            this.btnselect.Click += new System.EventHandler(this.btnselect_Click);
            // 
            // dataGridviewupdateinvoice
            // 
            this.dataGridviewupdateinvoice.BackgroundColor = System.Drawing.Color.White;
            this.dataGridviewupdateinvoice.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridviewupdateinvoice.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridviewupdateinvoice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(115)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridviewupdateinvoice.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridviewupdateinvoice.Location = new System.Drawing.Point(48, 398);
            this.dataGridviewupdateinvoice.Name = "dataGridviewupdateinvoice";
            this.dataGridviewupdateinvoice.Size = new System.Drawing.Size(951, 308);
            this.dataGridviewupdateinvoice.TabIndex = 113;
            // 
            // Update_Invoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.dataGridviewupdateinvoice);
            this.Controls.Add(this.btnselect);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.btnupdatesupplier);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtInvoice_No);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtmedicinename);
            this.Controls.Add(this.txttotalprice);
            this.Controls.Add(this.txtNoofUnit);
            this.Controls.Add(this.txtPricePerUnit);
            this.Controls.Add(this.txtdate);
            this.Controls.Add(this.txtmedicineid);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.lblsuppiler);
            this.Controls.Add(this.lblmedicinename);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblmedicineid);
            this.Name = "Update_Invoice";
            this.Size = new System.Drawing.Size(1104, 770);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridviewupdateinvoice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtInvoice_No;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtmedicinename;
        private System.Windows.Forms.TextBox txttotalprice;
        private System.Windows.Forms.TextBox txtNoofUnit;
        private System.Windows.Forms.TextBox txtPricePerUnit;
        private System.Windows.Forms.TextBox txtdate;
        private System.Windows.Forms.TextBox txtmedicineid;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblsuppiler;
        private System.Windows.Forms.Label lblmedicinename;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblmedicineid;
        private System.Windows.Forms.Button btnupdatesupplier;
        private System.Windows.Forms.Button btnview;
        private System.Windows.Forms.Button btnselect;
        private System.Windows.Forms.DataGridView dataGridviewupdateinvoice;
    }
}
