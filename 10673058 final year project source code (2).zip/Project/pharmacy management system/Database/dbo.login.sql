﻿CREATE TABLE [dbo].[Table]
(
	[username] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [password] VARCHAR(50) NOT NULL
)
